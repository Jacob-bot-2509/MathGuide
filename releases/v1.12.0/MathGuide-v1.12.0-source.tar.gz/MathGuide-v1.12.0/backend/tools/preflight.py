"""
演示/答辩前自检:一键验证全链路就绪,任何一项失败给出红色 [FAIL] 与修复提示。

检查项:
  1. 后端 /api/health
  2. 前端 5173 可访问
  3. 经 vite 代理登录(演示账号)
  4. 知识库装载(文档数 / 片段数)
  5. 三道抽查题端到端流式命中(中文知识 / 英文知识 / 闲聊)
  6. LLM / embedding 配置状态(信息项,不配置也可通过)

用法(backend 目录下,前后端已启动后执行):
    python tools/preflight.py

退出码:0 = 全部通过;1 = 有失败项。
"""
import json
import sys
import urllib.request
import urllib.error
from pathlib import Path

# 本机自检必须直连:urllib 默认读 Windows 系统代理(如 Clash 类工具),
# 会把 127.0.0.1 的请求截胡返回假 404,让自检误报「后端不可达」
# (实测:后端正常时 preflight 仍 FAIL,坑过一次)
urllib.request.install_opener(urllib.request.build_opener(urllib.request.ProxyHandler({})))

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import config  # noqa: E402 装载 .env.local(LLM key),与 main.py 同路径

config.load_env()

RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RESET = "\033[0m"

BASE = "http://127.0.0.1:8000"
FRONTEND = "http://localhost:5173"
DEMO_PHONE = "13600136000"
DEMO_PASSWORD = "demo123456"

# 抽查题:(提问, 期望关键词);期望为空 = 会话应答:
# 只要求非空回复且未降级为直答/框架(LLM 配置时由模型自然应答,不再限定词)
SMOKE_CASES = [
    ("什么是泰勒展开?", "泰勒"),
    ("What is Taylor expansion?", "Taylor"),
    ("你好", ""),
]

# 研究型冒烟(耗时较长,单独超时):要求回复含来源/链接(搜索→综合→引用全链路)
RESEARCH_SMOKE = ("泰勒展开的最新研究进展", 120)

failures: list[str] = []


def ok(msg: str) -> None:
    print(f"{GREEN}[OK]{RESET} {msg}")


def fail(msg: str, hint: str = "") -> None:
    print(f"{RED}[FAIL]{RESET} {msg}")
    if hint:
        print(f"      {YELLOW}修复:{hint}{RESET}")
    failures.append(msg)


def get(url: str, timeout: int = 8, token: str = ""):
    headers = {"User-Agent": "mg-preflight"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, headers=headers)
    return urllib.request.urlopen(req, timeout=timeout)


def post(url: str, body: dict, token: str = "", timeout: int = 20):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"), headers=headers)
    return urllib.request.urlopen(req, timeout=timeout)


def accumulate_stream(resp) -> str:
    """SSE 响应 → 累积正文(只拼 JSON 字符串帧;dict 帧是元信息如 mg_meta,跳过)"""
    full = ""
    for raw in resp:
        line = raw.decode("utf-8").strip()
        if not line.startswith("data:"):
            continue
        p = line[5:].strip()
        if not p or p == "[DONE]":
            continue
        try:
            v = json.loads(p)
        except json.JSONDecodeError:
            v = p
        if isinstance(v, str):
            full += v
    return full


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # 规避 Windows GBK 控制台
    print("=" * 56)
    print("  MathGuide 演示前自检")
    print("=" * 56)

    # 1. 后端健康
    try:
        body = json.loads(get(f"{BASE}/api/health").read())
        if body.get("ok") is not True:
            raise ValueError("health payload 不是 {ok: true}")
        ok("后端服务 8000 健康")
    except Exception:
        fail("后端服务 8000 不可达", "先启动后端:仓库根目录双击 dev.bat,或 uvicorn main:app --port 8000")
        return 1

    # 2. 前端
    try:
        if get(FRONTEND).status != 200:
            raise ValueError("前端返回非 200")
        ok("前端服务 5173 可访问")
    except Exception:
        fail("前端服务 5173 不可达", "先启动前端:npm run dev(dev.bat 会一并启动)")

    # 3. 经 vite 代理登录(演示账号)
    # 新 clone 的 data/ 被 gitignore,可能没有演示账号:404 时自动注册再重试,
    # 让自检在一台干净机器上也能一次跑通。
    token = ""
    try:
        body = json.loads(post(f"{BASE}/api/auth/login",
                               {"method": "password", "phone": DEMO_PHONE,
                                "password": DEMO_PASSWORD}).read())
        token = body.get("token", "")
    except urllib.error.HTTPError as e:
        if e.code != 404:
            fail(f"演示账号登录失败(HTTP {e.code})", "检查 data/users.json 是否被误删;密码应为 demo123456")
            return 1
        try:
            post(f"{BASE}/api/auth/register",
                 {"phone": DEMO_PHONE, "password": DEMO_PASSWORD})
        except urllib.error.HTTPError as reg_err:
            if reg_err.code != 409:
                fail(f"演示账号创建失败(HTTP {reg_err.code})", "检查后端日志")
                return 1
        except Exception:
            fail("演示账号创建失败(网络错误)", "确认后端正在运行")
            return 1
        try:
            body = json.loads(post(f"{BASE}/api/auth/login",
                                   {"method": "password", "phone": DEMO_PHONE,
                                    "password": DEMO_PASSWORD}).read())
            token = body.get("token", "")
        except Exception:
            fail("演示账号创建后登录仍失败", "检查后端日志与 users.json 写入权限")
            return 1
    except Exception:
        fail("演示账号登录失败(网络错误)", "确认后端正在运行")
        return 1
    if not token:
        fail("演示账号登录返回空 token", "检查后端日志")
        return 1
    ok(f"演示账号登录成功({DEMO_PHONE})")

    # 4. 知识库装载
    docs = sorted(Path(__file__).resolve().parent.parent.glob("knowledge/*.md"))
    if not docs:
        fail("知识库为空", "knowledge/ 目录需要至少一篇文档")
    else:
        ok(f"知识库装载 {len(docs)} 篇文档")

    # 5. 抽查题端到端
    for question, expect in SMOKE_CASES:
        try:
            resp = post(f"{BASE}/api/chat/stream", {"prompt": question}, token=token)
            full = accumulate_stream(resp)
            if expect:
                passed = expect.lower() in full.lower()
                hint = "检查 knowledge/ 对应文档 keywords 是否包含该主题词"
            else:
                passed = len(full) > 5 and "知识库检索" not in full and "三步走" not in full
                hint = "会话应答异常:可能 LLM 与直答链路均失败,查看后端控制台"
            if passed:
                ok(f"抽查题「{question}」命中({len(full)} 字)")
            else:
                fail(f"抽查题「{question}」回复不符合预期(期望「{expect or '会话应答'}」)", hint)
        except Exception as e:
            fail(f"抽查题「{question}」请求失败:{e}", "查看后端控制台报错")

    # 5b. 研究型全链路冒烟(搜索 → 精排 → 综合 → 引用)
    question, timeout = RESEARCH_SMOKE
    try:
        resp = post(f"{BASE}/api/chat/stream", {"prompt": question}, token=token, timeout=timeout)
        full = accumulate_stream(resp)
        if ("来源" in full or "References" in full or "http" in full) and len(full) > 100:
            ok(f"研究型冒烟「{question}」通过({len(full)} 字)")
        else:
            fail(f"研究型冒烟「{question}」未返回来源/引用", "检查深度搜索各源与综合链路日志")
    except Exception as e:
        fail(f"研究型冒烟「{question}」请求失败:{e}", "查看后端控制台报错")

    # 5c. 科研语料库(只读检查,不写入用户数据)
    try:
        docs_body = json.loads(get(f"{BASE}/api/research/docs", token=token).read())
        docs_list = docs_body.get("docs", [])
        ok(f"科研语料库接口可用(当前 {len(docs_list)} 篇论文)")
        if docs_list:
            result = json.loads(post(
                f"{BASE}/api/research/search",
                {"query": "研究方法", "topK": 3}, token=token).read())
            ok(f"科研检索冒烟 {len(result.get('hits', []))} 条命中 · "
               f"mode {result.get('mode', '?')}")
        else:
            print(f"{YELLOW}[i ]{RESET} 论文库为空,跳过科研检索冒烟")
    except urllib.error.HTTPError as e:
        fail(f"科研语料库接口异常(HTTP {e.code})", "确认 main.py 已注册 /api/research/* 路由")
    except Exception as e:
        fail(f"科研语料库检查失败:{e}", "查看后端控制台")

    # 5d. 实验数据表接口(只读列表)
    try:
        tables_body = json.loads(get(f"{BASE}/api/research/tables", token=token).read())
        ok(f"实验数据表接口可用(当前 {len(tables_body.get('tables', []))} 张)")
    except urllib.error.HTTPError as e:
        fail(f"实验数据表接口异常(HTTP {e.code})", "确认 main.py 已注册 /api/research/tables")
    except Exception as e:
        fail(f"实验数据表检查失败:{e}", "查看后端控制台")

    # 6. LLM / embedding 配置状态(信息项)
    from rag import embed, llm
    roles = []
    for r in ("main", "backup", "deep", "long"):
        spec = llm.resolve(r)
        roles.append(f"{r}:{'✓' if spec else '未配'}")
    print(f"{YELLOW}[i ]{RESET} LLM 角色: {' | '.join(roles)}")
    print(f"{YELLOW}[i ]{RESET} Embedding:{'已配置 ' + embed.model_name() if embed.is_configured() else '未配置(关键词检索模式,可正常演示)'}")

    print("=" * 56)
    if failures:
        print(f"{RED}自检未通过:{len(failures)} 项失败{RESET}")
        return 1
    print(f"{GREEN}全部检查通过,可以放心演示{RESET}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
