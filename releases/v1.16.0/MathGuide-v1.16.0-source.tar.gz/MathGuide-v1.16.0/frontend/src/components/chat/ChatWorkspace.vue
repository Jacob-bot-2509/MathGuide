<script setup lang="ts">
/**
 * 聊天工作区(学习辅助 / 科学研究共用外壳)。
 *
 * 两个板块的用户界面与交互完全一致,但会话、归纳本、回收站记录与后端链路
 * 按 workspace 完全隔离:学习区只走学习链路,科研区独占研究检索链路。
 *
 * 会话架构(上下文栈):
 * - 每次进入页面都开启全新会话;旧会话自动归档,
 *   在问题归纳面板按板块检索,可随时跳回原上下文。
 * - 每个会话归属一个高等数学板块;首次提问时绑定板块。
 * - 检测到与当前会话不同类型的问题 → 先检索同板块旧会话(上下文栈),
 *   命中则切回该会话延续上下文,否则新开一个会话;
 *   同类型问题的延续拓展 → 保持当前会话,避免不同类型问题相互纠缠。
 * - 所有会话持久化到 localStorage(记忆功能),按工作区分键;
 *   问题归纳面板按板块汇总,点击问题可跳回当时所在的对话。
 *
 * 回复由后端 LLM 流式生成(services/chatService,SSE 契约);
 * 问题分类由前端关键词预判,后端路由做最终裁决。
 */
import { computed, defineAsyncComponent, markRaw, nextTick, onBeforeUnmount, onMounted, ref, toRef } from 'vue'
import { onBeforeRouteLeave, useRoute, useRouter } from 'vue-router'
import MathText from '@/components/chat/MathText.vue'
import DiagramBlockView from '@/components/diagram/DiagramBlock.vue'
import DiagramBoundary from '@/components/diagram/DiagramBoundary.vue'
import { appendDiagram, parseDiagramEvent, splitMessageBlocks, type DiagramBlock } from '@/utils/diagramSpec'
import { needsDiagram, planDiagram } from '@/services/diagramService'
import CategoryPanel from '@/components/chat/CategoryPanel.vue'
import ResearchScopePanel from '@/components/chat/ResearchScopePanel.vue'
import ResearchArchivePanel from '@/components/chat/ResearchArchivePanel.vue'
import PaperWorkspace from '@/components/research/PaperWorkspace.vue'
import PaperImportPrompt from '@/components/research/PaperImportPrompt.vue'
import TodoPanel from '@/components/chat/TodoPanel.vue'
import DocModal from '@/components/chat/DocModal.vue'
import TodoReminder from '@/components/chat/TodoReminder.vue'
import NotebookPanel from '@/components/chat/NotebookPanel.vue'
import FormulaPanel from '@/components/chat/FormulaPanel.vue'
import SpeechTips from '@/components/chat/SpeechTips.vue'
import MgSwitch from '@/components/common/MgSwitch.vue'
import { COMMANDS, RESEARCH_COMMANDS } from '@/utils/commands'
import { catName, cmdDefault, cmdHint, cmdName, t } from '@/utils/i18n'
import { speechToMath, type ChatMeta, type ChatStreamHandle } from '@/services/chatService'
import { getResearchTable } from '@/services/researchTableService'
import { getResearchDocMeta, uploadTempPaper, type PaperAction, type ResearchDoc } from '@/services/researchService'
import { deletePaperHistory, importTempPaper } from '@/services/literatureService'
import { downloadBlob, exportSurveyPdf } from '@/services/docService'
import { CATEGORIES, DISPLAY_KEYS, FALLBACK_CATEGORY, categoryByKey, classifyQuestion, isChitchat } from '@/utils/classifier'
import { detectAmbiguous, topicById, type AmbiguousOption } from '@/utils/ambiguous'
import { usePaperChat } from '@/composables/usePaperChat'
import { settingsState, updateSettings } from '@/stores/settings'
import { isAllSelected, scopeForRequest, selectedSources } from '@/stores/researchScope'
import {
  MAX_SESSIONS,
  sessionStore,
  type ChatAttachment,
  type ChatMsg,
  type ChatSession,
  type Workspace,
} from '@/stores/sessions'
import { addToTrash } from '@/stores/trash'
import { notebookStore } from '@/stores/notebook'
import { setTodoWorkspace } from '@/stores/todo'
import { compressImage } from '@/utils/avatar'
import { extractPdfText } from '@/utils/fileText'
import { beautifyMath, cachedConvert, normalizeSpeechCase, saveConvert, speechMathConvert } from '@/utils/speechMath'
import { showToast } from '@/utils/toast'
import { chapterNameFromCmd } from '@/utils/cmdLink'
import { splitStableBlocks } from '@/utils/mathBlocks'

const props = withDefaults(defineProps<{ workspace?: Workspace }>(), { workspace: 'learn' })

const router = useRouter()
const route = useRoute()

/** 科研检索分栏:懒加载整页检索组件,分栏与独立页共用同一套逻辑 */
const ResearchSearchView = defineAsyncComponent(
  () => import('@/views/ResearchSearchView.vue'),
)

const SPLIT_KEY = 'mg-research-split'
const SPLIT_DEFAULT = 0.4
const SEARCH_MIN_PX = 320
const CHAT_MIN_PX = 380
const SPLIT_MIN_WIDTH = 1100

const searchOpen = ref(false)
const splitResizing = ref(false)
const workspaceBodyRef = ref<HTMLElement | null>(null)
const splitRatio = ref(loadSplitRatio())
const searchPaneRef = ref<{
  locateForQuestion: (q: string) => Promise<void>
  reloadDocs: () => Promise<void>
  applyPaperActions: (actions: PaperAction[], requestId?: string) => Promise<void>
  openDocForActions: (
    docId: string, title: string, actions: PaperAction[], requestId?: string,
  ) => Promise<void>
} | null>(null)
const currentPaper = ref<{ docId: string; title: string } | null>(null)
/** 拖入本次对话的论文:直接作为对话上下文,结束时再询问是否入库。 */
const stagedPaper = ref<{ docId: string; title: string } | null>(null)
const stagedPapers = ref<Array<{
  docId: string
  title: string
  pages: number
  msgId: number
}>>([])
const importPromptOpen = ref(false)
const importPromptBusy = ref(false)
let importPromptResolve: ((proceed: boolean) => void) | null = null
/** 从数据表页带过来的表:作为对话上下文,随消息发送 tableId */
const tableContext = ref<{ id: string; title: string } | null>(null)

function onPaperChange(paper: { docId: string; title: string } | null): void {
  currentPaper.value = paper
  if (paper) stagedPaper.value = null
}

/** 论文动作与流式入口:和 PaperWorkspace 共用同一套动作帧处理。
 *  只有科研区有论文上下文;学习区 getTarget 恒为 null,不会触发论文动作。 */
const paperChat = usePaperChat({
  getTarget: () => (isResearch.value
    ? currentPaper.value || stagedPaper.value
    : null),
  applyActions: (target, actions, requestId) => {
    void applyPaperActionsFromModel(actions, requestId, target)
  },
})

/** 模型完成入库:更新拖入论文状态,刷新档案/检索页,后续按库内论文处理。 */
function markPaperImported(info: {
  docId: string; title?: string; status?: string; reason?: string
}): void {
  if (!info?.docId) return
  const paper = stagedPapers.value.find((item) => item.docId === info.docId)
  if (paper) {
    const msg = findMessage(paper.msgId)
    if (msg?.paperImport) {
      msg.paperImport.status = info.status === 'imported' ? 'imported' : 'pending'
    }
    if (info.title) paper.title = info.title
  }
  if (stagedPaper.value?.docId === info.docId && info.title) {
    stagedPaper.value = { ...stagedPaper.value, title: info.title }
  }
  if (info.status === 'imported') {
    showToast(t('learn.paperImported'))
    void searchPaneRef.value?.reloadDocs()
    void archivePanelRef.value?.reload?.()
  } else if (info.status === 'failed') {
    showToast(info.reason || t('learn.paperImportFail'))
  }
  if (!flushSessions(true)) showToast(t('learn.toastStorage'))
}

async function loadTableContext(): Promise<void> {
  const tableId = typeof route.query.tableId === 'string' ? route.query.tableId : ''
  if (!tableId || !isResearch.value) return
  try {
    const table = await getResearchTable(tableId)
    tableContext.value = { id: table.id, title: table.title }
  } catch {
    tableContext.value = null
  }
}

function loadSplitRatio(): number {
  try {
    const value = Number(localStorage.getItem(SPLIT_KEY))
    return Number.isFinite(value) && value > 0 ? clampSplit(value) : SPLIT_DEFAULT
  } catch {
    return SPLIT_DEFAULT
  }
}

function clampSplit(value: number, width = workspaceBodyRef.value?.clientWidth ?? 0): number {
  if (width >= SEARCH_MIN_PX + CHAT_MIN_PX) {
    const min = SEARCH_MIN_PX / width
    const max = 1 - CHAT_MIN_PX / width
    return Math.min(max, Math.max(min, value))
  }
  return Math.min(0.6, Math.max(0.4, value))
}

function saveSplitRatio(): void {
  try {
    localStorage.setItem(SPLIT_KEY, String(splitRatio.value))
  } catch {
    /* 忽略 */
  }
}

/** 检索按钮:按设置与本机宽度选择分栏或独立页 */
function openResearchSearch(): void {
  if (!isResearch.value) return
  if (settingsState.researchSearchMode === 'page' || window.innerWidth < SPLIT_MIN_WIDTH) {
    router.push('/research/search')
    return
  }
  searchOpen.value = !searchOpen.value
  if (searchOpen.value) {
    nextTick(() => {
      splitRatio.value = clampSplit(
        splitRatio.value, workspaceBodyRef.value?.clientWidth ?? 0)
    })
  }
}

function startSplitDrag(e: PointerEvent): void {
  const body = workspaceBodyRef.value
  if (!body) return
  e.preventDefault()
  splitResizing.value = true
  const rect = body.getBoundingClientRect()
  const move = (ev: PointerEvent) => {
    const ratio = (rect.right - ev.clientX) / rect.width
    splitRatio.value = clampSplit(ratio, rect.width)
  }
  const up = () => {
    splitResizing.value = false
    window.removeEventListener('pointermove', move)
    window.removeEventListener('pointerup', up)
    saveSplitRatio()
  }
  window.addEventListener('pointermove', move)
  window.addEventListener('pointerup', up)
}

function nudgeSplit(delta: number): void {
  splitRatio.value = clampSplit(splitRatio.value + delta)
  saveSplitRatio()
}

function resetSplit(): void {
  splitRatio.value = clampSplit(SPLIT_DEFAULT)
  saveSplitRatio()
}

function onSplitAsk(prompt: string): void {
  if (prompt) send(prompt)
}

/** 模型动作到达:确保右侧阅读器存在,再跳页/高亮/批注。
 *  独立页面模式不强行跳转,避免打断当前对话。 */
async function applyPaperActionsFromModel(
  actions: PaperAction[],
  requestId = '',
  targetOverride: { docId: string; title?: string } | null = null,
): Promise<void> {
  if (!isResearch.value) return
  const target = targetOverride || currentPaper.value || stagedPaper.value
  if (!target) return
  if (!searchPaneRef.value) {
    if (settingsState.researchSearchMode === 'page'
      || window.innerWidth < SPLIT_MIN_WIDTH) return
    searchOpen.value = true
    for (let i = 0; i < 20 && !searchPaneRef.value; i += 1) {
      await new Promise((resolve) => setTimeout(resolve, 50))
    }
  }
  if (currentPaper.value) {
    await searchPaneRef.value?.applyPaperActions(actions, requestId)
  } else {
    await searchPaneRef.value?.openDocForActions(
      target.docId, target.title || '', actions, requestId)
  }
}

/** 窗口变窄时收起分栏,避免聊天区被压到不可用 */
function onWorkspaceResize(): void {
  if (searchOpen.value && window.innerWidth < SPLIT_MIN_WIDTH) searchOpen.value = false
}

/** 科研区:独占研究检索链路与搜索范围面板;学习区不跨区查文献 */
const isResearch = computed(() => props.workspace === 'research')

/* 文件导入上限(拖拽一次最多 3 个;粘贴文本截断上限,保护本地存储与请求体积) */
const MAX_DROP_FILES = 3
const PASTE_TEXT_MAX = 3000

/** 触屏设备判定:手机/平板用「粘贴导入」替代拖拽(拖拽仅限电脑端) */
const isTouchDevice = window.matchMedia('(pointer: coarse)').matches

/* 文本/PDF 教材:上传时提取正文随附件保存,章节导航等指令可基于内容工作。
   上限 3 万字,发挥 QwenLong 长上下文能力(移动端粘贴导入仍 3 千字) */
const FILE_TEXT_EXT = /\.(txt|md|markdown)$/i
const FILE_TEXT_MAX = 30000

/* 会话上下文栈:按工作区取独立仓库,两区同号 sessionId 也不会串档 */
const store = sessionStore(props.workspace)
const sessions = toRef(store.state, 'sessions')
const activeId = toRef(store.state, 'activeId')
const { persistSessions, flushSessions, nextMsgId, nextSessionId } = store

/* 归纳本同样按工作区隔离:科研区收的题不会出现在学习区 */
const notebooks = notebookStore(props.workspace)

/* 待办也按工作区隔离:学习区的任务不会出现在科研区 */
setTodoWorkspace(props.workspace)

/* 指令栏:学习区不显示搜索范围;科研区不设问题记录,改为研究档案 */
const commands = computed(() =>
  isResearch.value
    ? RESEARCH_COMMANDS
    : COMMANDS.filter((c) => c.key !== '搜索范围'),
)
const input = ref('')
/** 浮层面板统一开关:同一时间只允许一个面板展开(点开新的自动收起旧的),
    关闭后其余按钮才可点(全屏遮罩拦截) */
type PanelKind = 'summary' | 'scope' | 'notebook' | 'formula' | 'todo' | 'archive'
const activePanel = ref<PanelKind | null>(null)
const archivePanelRef = ref<InstanceType<typeof ResearchArchivePanel> | null>(null)
const paperDocId = ref<string | null>(null)

function openPaperWorkspace(doc: ResearchDoc): void {
  // 论文工作台及其论文图解只属于科学研究;学习辅助没有论文图鉴。
  if (!isResearch.value) return
  activePanel.value = null
  paperDocId.value = doc.id
}
const docOpen = ref(false)

function closePanel(): void {
  if (activePanel.value === 'archive' && archivePanelRef.value && !archivePanelRef.value.confirmClose()) return
  activePanel.value = null
}

function togglePanel(kind: PanelKind) {
  if (activePanel.value === 'archive' && archivePanelRef.value && !archivePanelRef.value.confirmClose()) return
  tipsOpen.value = false
  activePanel.value = activePanel.value === kind ? null : kind
}

/** 面板锚点:对齐所属按钮(相对 .learn 的 left/top/width) */
const panelAnchor = ref<{ left: number; top: number; width: number } | null>(null)

/** 量取按钮位置(面板出现前调用;按钮一定在页面上,量不到则退化为不传) */
function anchorTo(selector: string) {
  const btn = document.querySelector<HTMLElement>(selector)
  const root = document.querySelector<HTMLElement>('.learn')
  if (!btn || !root) {
    panelAnchor.value = null
    return
  }
  const b = btn.getBoundingClientRect()
  const r = root.getBoundingClientRect()
  panelAnchor.value = { left: b.left - r.left, top: b.bottom - r.top, width: b.width }
}
const tipsOpen = ref(false)
const flashMsgId = ref(0)
const inputEl = ref<HTMLTextAreaElement | null>(null)
const listEl = ref<HTMLDivElement | null>(null)

/* 后台流:不同会话的输出并行生成,切换界面不中断;按消息 id 索引便于精确取消 */
let streams = new Map<number, ChatStreamHandle>()
const timers = new Map<number, ReturnType<typeof setTimeout>>()
let flashTimer: ReturnType<typeof setTimeout> | null = null

const activeSession = computed(() => sessions.value.find((s) => s.id === activeId.value))

/** 是否"正在回答提问"(仅剩首条问候流时不算忙碌 —— 问候可被提问打断) */
const busy = computed(() => {
  const s = activeSession.value
  if (!s) return false
  const first = s.messages[0]
  if (first?.streaming) return false
  return s.messages.some((m) => m.streaming)
})

/* 问题归纳:所有板块常驻显示(无问题的板块显示 0),按教学板块顺序排列 */
const summary = computed(() => {
  const map = new Map<string, { key: string; label: string; color: string; questions: { id: number; text: string }[] }>()
  for (const c of [...CATEGORIES, FALLBACK_CATEGORY]) {
    map.set(c.key, { key: c.key, label: catName(c.key), color: c.color, questions: [] })
  }
  for (const s of sessions.value) {
    if (!s.cat) continue
    const entry = map.get(s.cat.key)
    if (!entry) continue
    for (const m of s.messages) {
      // 寒暄/闲聊等非问题语句不进问题归纳
      if (m.role === 'user' && !m.chitchat) entry.questions.push({ id: m.id, text: m.content })
    }
  }
  return DISPLAY_KEYS.flatMap((k) => {
    const v = map.get(k)
    return v ? [{ ...v, count: v.questions.length }] : []
  })
})

/** 问题总数:直接取 summary 的汇总,不再单独遍历会话重数一遍 */
const questionCount = computed(() => summary.value.reduce((n, c) => n + c.count, 0))

/* ---------- 会话管理(上下文栈) ---------- */

function createSession(cat?: ChatSession['cat']): ChatSession {
  const s: ChatSession = { id: nextSessionId(), cat, messages: [] }
  sessions.value.push(s)
  if (sessions.value.length > MAX_SESSIONS) sessions.value.shift()
  activeId.value = s.id
  persistSessions()
  return s
}

/** 页面卸载时:停止全部后台流与定时器,保留已生成内容 */
function stopAllStreams() {
  for (const s of streams.values()) s.cancel()
  streams.clear()
  for (const t of timers.values()) clearTimeout(t)
  timers.clear()
  for (const s of sessions.value) {
    for (const m of s.messages) {
      m.streaming = false
      m.thinking = false
    }
  }
  flushSessions()  // 离开学习页前立即落盘,不等 debounce
}

/* ---------- 对话 ---------- */

/** 滚到底部;流式期间用瞬时滚动(避免 40ms 级 smooth 动画排队争抢主线程),主动发送等场景用平滑 */
function scrollBottom(smooth = true) {
  nextTick(() => {
    listEl.value?.scrollTo({ top: listEl.value.scrollHeight, behavior: smooth ? 'smooth' : 'auto' })
  })
}

/** 是否"贴底"(距底部不足 60px):流式输出只在贴底时自动跟随;
 *  用户上拉回看时保持原地,不把对话框往下拽;重新滚回底部即恢复跟随 */
let pinnedToBottom = true

function onListScroll() {
  const el = listEl.value
  if (!el) return
  pinnedToBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 60
}

function autoGrow() {
  const el = inputEl.value
  if (!el) return
  el.style.height = 'auto'
  el.style.height = `${Math.min(el.scrollHeight, 160)}px`
}

/** 组装最近几轮历史(供模型理解上下文):去掉刚发的本条用户消息
    (它作为 prompt 单独传递),排除流式中的消息,单条截断;
    粘贴导入的文本文件以正文入历史,后续追问可基于文件内容作答。
    被中断的回答(interrupted)也排除:半截话混进上下文,模型
    会把它当成完整的一轮去理解,徒增困惑。
    上限 16 条:更早的对话由后端滚动摘要压缩,早期上下文不丢失 */
function buildHistory(session: ChatSession, beforeId?: number): ChatMeta['history'] {
  const end = beforeId === undefined
    ? session.messages.length - 1
    : session.messages.findIndex((message) => message.id === beforeId)
  const upTo = end >= 0 ? session.messages.slice(0, end) : session.messages.slice(0, -1)
  return upTo
    .filter((m) => !m.streaming && !m.clarify && m.content && !m.interrupted && !m.stopped)
    .slice(-16)
    .map((m) => ({ role: m.role, content: (m.attachment?.text || m.content).slice(0, 400) }))
}

function clarifyScope(topicId: string): string {
  const topic = topicById(topicId)
  if (!topic) return ''
  return settingsState.language === 'en' ? topic.scope.en : topic.scope.zh
}

function clarifyOptions(topicId: string): AmbiguousOption[] {
  return topicById(topicId)?.options ?? []
}

function clarifyLabel(option: AmbiguousOption): string {
  return settingsState.language === 'en' ? option.label.en : option.label.zh
}

function clarifyHint(option: AmbiguousOption): string {
  return settingsState.language === 'en' ? option.hint.en : option.hint.zh
}

/** 用户选定跨板块方向后:把澄清气泡原地变成流式回答 */
function pickClarify(msg: ChatMsg, optionIndex: number): void {
  const clarity = msg.clarify
  const topic = clarity ? topicById(clarity.topicId) : null
  const option = topic?.options[optionIndex]
  if (!clarity || !topic || !option) return
  const session = sessions.value.find((item) => item.messages.some((message) => message.id === msg.id))
  if (!session) return

  const cat = categoryByKey(option.key)
  if (cat) session.cat = cat
  msg.clarify = undefined
  msg.content = ''
  msg.streaming = true
  msg.thinking = true

  const zh = settingsState.language !== 'en'
  const label = zh ? option.label.zh : option.label.en
  const hint = zh ? option.hint.zh : option.hint.en
  const prompt = zh
    ? `${clarity.question}\n\n[范围] 请从${label}角度回答,聚焦:${hint}。`
    : `${clarity.question}\n\n[Scope] Answer from the ${label} perspective, focusing on: ${hint}.`
  const history = buildHistory(session, msg.id)
  activeId.value = session.id
  pinnedToBottom = true
  streamInto(session, msg, prompt, {
    sessionId: session.id,
    categoryKey: option.key,
    history,
  })
  persistSessions()
  scrollBottom()
}


const exportMenu = ref<number | null>(null)
/** 正在生成 PDF 的研究消息 id(按钮转「生成中…」) */
const exportingMsg = ref<number | null>(null)

/** 导出研究综述:语言由菜单选定后执行;生成需 20~60 秒,期间按钮禁用 */
async function doExport(msg: ChatMsg, lang: 'zh' | 'en') {
  exportMenu.value = null
  if (exportingMsg.value !== null) return
  exportingMsg.value = msg.id
  try {
    const { blob } = await exportSurveyPdf(msg.content, lang)
    // 下载文件名用该消息的首行文字(通常是综述标题),非法文件名字符替换掉
    const title = (msg.content.split('\n').find((l) => l.trim()) || '研究综述')
      .slice(0, 40).replace(/[\\/:*?"<>|]/g, '_')
    downloadBlob(blob, `${title}-${lang}.pdf`)
    showToast(t('learn.exportDone'))
  } catch {
    showToast(t('learn.exportFailed'))
  } finally {
    exportingMsg.value = null
  }
}

/** 流式正文按稳定块渲染:已完成的块 props 不变,Vue 跳过重复解析/重渲染 */
function blocksOf(text: string): string[] {
  return splitStableBlocks(text)
}

/** 消息正文按图解锚点切成文本/图块;文本仍走稳定块渲染。 */
function messageBlocks(msg: ChatMsg): Array<{
  key: string
  kind: 'text' | 'diagram'
  text?: string
  diagram?: DiagramBlock
}> {
  const out: Array<{
    key: string
    kind: 'text' | 'diagram'
    text?: string
    diagram?: DiagramBlock
  }> = []
  splitMessageBlocks(msg.content, msg.diagrams).forEach((segment, si) => {
    if (segment.kind === 'diagram') {
      out.push({ key: `d-${si}-${segment.diagram.id}`, kind: 'diagram', diagram: segment.diagram })
      return
    }
    blocksOf(segment.text).forEach((text, ti) => {
      out.push({ key: `t-${si}-${ti}`, kind: 'text', text })
    })
  })
  return out
}

const diagramBusy = ref<number | null>(null)

function previousQuestion(msg: ChatMsg): string {
  for (const session of sessions.value) {
    const index = session.messages.findIndex((item) => item.id === msg.id)
    if (index < 0) continue
    return [...session.messages.slice(0, index)]
      .reverse().find((item) => item.role === 'user')?.content || ''
  }
  return ''
}

function hasDiagram(msg: ChatMsg): boolean {
  return !!msg.diagrams?.length
}

async function requestDiagram(
  msg: ChatMsg, question = '', silent = false,
): Promise<void> {
  const prompt = question || previousQuestion(msg)
  if (diagramBusy.value === msg.id || !msg.content.trim() || !prompt.trim()) return
  // 已有图解(自动或手动):直接复用已存快照,不再调模型加图。
  if (hasDiagram(msg)) return
  diagramBusy.value = msg.id
  try {
    const paperId = currentPaper.value?.docId || stagedPaper.value?.docId
    const spec = await planDiagram({
      question: prompt,
      answer: msg.content,
      paperId,
    })
    if (!spec) {
      if (!silent) showToast(t('diagram.fail'))
      return
    }
    msg.diagrams = markRaw(appendDiagram(msg.diagrams, {
      id: `manual-${msg.id}-${Date.now()}`,
      anchorIndex: msg.content.length,
      spec,
    }))
    persistSessions()
  } catch {
    if (!silent) showToast(t('diagram.fail'))
  } finally {
    diagramBusy.value = null
  }
}

/** 让某会话的一条助手消息开始流式接收回复(输出在所属会话内进行,切换界面不中断) */
function streamInto(session: ChatSession, reply: ChatMsg, prompt: string, meta?: ChatMeta) {
  // 增量节流:高频 chunk 先攒进 pending,约每 24ms 合并提交一次;
  // MathText 对已闭合公式有渲染缓存,单次提交开销极小,不会随正文增长变慢
  let pending = ''
  let commit: ReturnType<typeof setTimeout> | null = null
  // 本次流是否已由 onError 收过尾:失败路径 chatService 会补一次 onDone,
  // 那是幂等清理,不该再叠一层「已中断」标记
  let failed = false
  const flush = () => {
    commit = null
    if (!pending) return
    reply.content += pending
    pending = ''
    // 贴底才跟随滚动:用户上拉阅读时不打扰
    if (session === activeSession.value && pinnedToBottom) scrollBottom(false)
  }
  const stream = paperChat.stream(prompt, {
    onMeta: (meta) => {
      // 后端路由才知道的标记:研究型回答打上 research,导出入口只对它显示
      const inner = (meta as {
        mg_meta?: {
          research?: boolean
          paperImported?: {
            docId: string; title?: string; status?: string; reason?: string
          }
        }
      }).mg_meta
      if (inner?.research) reply.research = true
      if (inner?.paperImported) markPaperImported(inner.paperImported)
      const diagram = parseDiagramEvent(meta)
      if (diagram) {
        reply.diagrams = markRaw(appendDiagram(reply.diagrams, diagram))
        persistSessions()
      }
    },
    onDelta: (t) => {
      reply.thinking = false
      pending += t
      if (!reply.content) {
        // 首个增量立即上屏(欢迎语/回复的第一句话即刻出现),后续增量再走节流
        flush()
      } else if (!commit) {
        commit = setTimeout(flush, 24)
      }
    },
    onDone: (_full, complete) => {
      if (commit) {
        clearTimeout(commit)
        commit = null
      }
      flush() // 提交最后的残量,避免丢尾
      reply.streaming = false
      reply.thinking = false
      if (!reply.content) {
        // 一字未出:主动停止给停止提示(此时流已被 cancelReply 移出 streams);
        // 被中断则给连接失败提示,否则气泡空着,用户以为卡住了
        if (!streams.has(reply.id)) reply.content = t('learn.stoppedNote')
        else if (!complete && !failed) reply.content = t('learn.errStream')
      } else if (!complete && !failed) {
        // 连接断在后端 [DONE] 之前(后端重启 / 网络中断):手里的字只是半截。
        // 不标记的话,这半截回答和完整回答在界面上长得一模一样,用户无从察觉
        reply.interrupted = true
      }
      streams.delete(reply.id)
      persistSessions()
      if (!failed && complete && reply.content && needsDiagram(prompt)
        && !reply.diagrams?.length) {
        void requestDiagram(reply, prompt, true)
      }
    },
    // 请求失败(典型:后端未启动 / 限流 429)时,若一字未出则显示对应提示,
    // 避免气泡永远停留在"思考中"且无任何反馈。
    // 失败路径 onDone 不再触发(settled 拦截),清理须在此完整收尾,
    // 否则 streaming 永真 → 发送按钮永远"生成中"。
    onError: (err?: unknown) => {
      failed = true
      if (commit) {
        clearTimeout(commit)
        commit = null
      }
      flush() // 先提交已收到的残量,不丢内容
      reply.thinking = false
      if (!reply.content) {
        reply.content = (err as { status?: number })?.status === 429
          ? t('learn.toastRateLimit')
          : t('learn.errStream')
      } else {
        // 已经有内容还报错 = 流断在半途(实测后端被杀时是连接重置,不走干净关闭那条路)。
        // 这半截同样得标记,否则它和完整回答在界面上没有区别
        reply.interrupted = true
      }
      reply.streaming = false
      streams.delete(reply.id)
      persistSessions()
    },
  }, { workspace: props.workspace, ...meta })
  streams.set(reply.id, stream)
}

/** 延迟后开始流式输出(模拟"思考"阶段);定时器按消息 id 记录,便于精确取消 */
function scheduleStream(session: ChatSession, reply: ChatMsg, prompt: string, delay: number, meta?: ChatMeta) {
  const timer = setTimeout(() => {
    timers.delete(reply.id)
    if (reply.streaming) streamInto(session, reply, prompt, meta)
  }, delay)
  timers.set(reply.id, timer)
}

/** 精确取消一条回复:等待中的定时器与进行中的流一并清理(含尚未启动的孤儿流) */
function cancelReply(id: number) {
  const timer = timers.get(id)
  if (timer) {
    clearTimeout(timer)
    timers.delete(id)
  }
  const stream = streams.get(id)
  if (stream) {
    stream.cancel()
    streams.delete(id)
  }
}

/** 停止当前会话的生成:进行中的流中止后走正常收尾(保留已生成内容),
    尚未启动的(思考阶段)同步收尾,避免"生成中"卡死 */
function stopGenerating() {
  const session = activeSession.value
  if (!session) return
  for (const m of session.messages) {
    if (!m.streaming) continue
    const hadContent = !!m.content
    cancelReply(m.id)
    m.thinking = false
    if (!streams.has(m.id)) {
      m.streaming = false
      if (!m.content) m.content = t('learn.stoppedNote')
    }
    // 有已生成内容才允许续写;空回答只显示停止提示
    m.stopped = hadContent && !!m.content
  }
  persistSessions()
}

/** 续写被「停止生成」截断的回答:原问题 + 已生成正文发给后端,增量追加到同一条消息 */
function resumeReply(msg: ChatMsg) {
  const session = activeSession.value
  if (!session || msg.streaming || !msg.content) return
  if (session.messages.some((m) => m.streaming)) {
    showToast(t('learn.toastBusy'))
    return
  }
  const idx = session.messages.findIndex((m) => m.id === msg.id)
  if (idx < 0) return
  const question = [...session.messages.slice(0, idx)].reverse().find((m) => m.role === 'user')
  if (!question) return

  const partial = msg.content
  msg.stopped = false
  msg.interrupted = false
  msg.thinking = true
  msg.streaming = true
  streamInto(session, msg, question.content, {
    sessionId: session.id,
    categoryKey: session.cat?.key,
    resume: true,
    partial,
  })
  pinnedToBottom = true
  scrollBottom()
  persistSessions()
}

function send(text?: string, cmd?: string) {
  let content = (text ?? input.value).trim()
  if (!content) return
  // 阅读器打开时:先请求当前论文的命中段落,阅读器会滚到对应页并高亮。
  // 后端 paper_actions 到达后会以模型定位结果覆盖,两条路径都保留。
  if (isResearch.value && currentPaper.value && !cmd) {
    void searchPaneRef.value?.locateForQuestion(content)
  }

  // 寒暄/闲聊:不分类、不切换或新开会话,只就话答话
  const chitchat = isChitchat(content)
  // 科研区是一条持续对话:检索、定位、批注都依赖当前上下文,
  // 不能因为问题换了板块就被分类器切到旧会话或新开对话。
  // 学习区仍保留按板块切换会话的旧行为。
  const keepCurrentSession = isResearch.value
  // 跨板块知识点:裸词先问方向,不要在用户没选之前就绑定板块
  const ambiguous = !isResearch.value && !cmd && !chitchat ? detectAmbiguous(content) : null
  const catInfo = chitchat || ambiguous ? undefined : classifyQuestion(content)

  // 会话选择:同类型延续当前会话;不同类型检索同板块旧会话,否则新开;
  // 闲聊沿用当前会话(无会话则开一个未归类会话,不绑定板块、不进归纳面板)
  let session = activeSession.value
  if (!session) session = createSession(catInfo)

  if (catInfo) {
    if (!session.cat) {
      // 新会话首次提问:绑定板块
      session.cat = catInfo
    } else if (session.cat.key !== catInfo.key && !keepCurrentSession) {
      const current = session
      const existing = [...sessions.value].reverse().find((s) => s.cat?.key === catInfo.key && s.id !== current.id)
      if (existing) {
        activeId.value = existing.id
        session = existing
      } else {
        session = createSession(catInfo)
      }
    }
  }

  // 新问题进来时丢弃未回答的澄清气泡:同一时刻只保留一个待选方向
  if (session.messages.some((m) => m.clarify)) {
    session.messages = session.messages.filter((m) => !m.clarify)
  }

  // 章节知识导航:会话里已有教材文本时随指令携带正文,模型只划分章节列表
  if (cmd === '章节知识导航') {
    const tb = latestTextbookText(session)
    if (tb) content = `${content}\n\n<教材文本>:\n${tb}`
  }

  // 目标会话仍在生成回复时暂不接收新问题(每会话一次一问);
  // 例外:仅剩首条问候流未完成 → 直接打断问候,让位给真实提问。
  // 被打断时给出提示并保留输入内容,避免问题被静默丢弃
  if (session.messages.some((m) => m.streaming)) {
    if (!session.messages[0]?.streaming) {
      showToast(t('learn.toastBusy'))
      return
    }
    cancelReply(session.messages[0].id)
    session.messages.shift()
  }

  session.messages.push({ id: nextMsgId(), role: 'user', content, cmd, chitchat: chitchat || undefined })
  input.value = ''
  autoGrow()
  pinnedToBottom = true // 自己刚发消息:强制回底并恢复跟随
  scrollBottom()

  // 跨板块裸词:先渲染一张选择卡,用户选完再请求后端
  if (ambiguous) {
    session.messages.push({
      id: nextMsgId(),
      role: 'assistant',
      content: '',
      clarify: { topicId: ambiguous.id, question: content },
    })
    persistSessions()
    scrollBottom()
    return
  }

  persistSessions()

  // prompt 原文随流发送;指令与归属随 ChatMeta 传给后端(契约 ChatRequest);
  // 最近几轮历史一并携带,模型可理解上下文
  const history = buildHistory(session)
  const reply: ChatMsg = {
    id: nextMsgId(), role: 'assistant', content: '', streaming: true, thinking: true,
    // 章节列表回复打标:「返回」按钮跳转的目标
    nav: cmd === '章节知识导航' ? 'list' : undefined,
  }
  session.messages.push(reply)
  // 流式回调必须操作响应式代理(数组里读出的那条),而不是 push 进去的裸对象;
  // 裸对象上的修改不触发 Vue 更新 → 界面会"凝固"到下一次交互才刷新
  const live = session.messages[session.messages.length - 1]
  scheduleStream(session, live, content, 450, {
    cmd,
    sessionId: session.id,
    categoryKey: session.cat?.key,
    history,
    // 搜索范围只属于科研链路:学习区不传,避免误触发跨区文献检索
    sources: isResearch.value ? scopeForRequest() : undefined,
    paperId: isResearch.value
      ? (stagedPaper.value?.docId || currentPaper.value?.docId)
      : undefined,
    tableId: isResearch.value ? tableContext.value?.id : undefined,
  })
}

/** 点击指令:直接执行对应功能 */
function runCommand(cmd: string) {
  // 生成文档 = 本地弹窗:按当前对话/问题归纳/独立要求生成,不走聊天流
  if (cmd === '生成文档') {
    docOpen.value = true
    activePanel.value = null
    tipsOpen.value = false
    return
  }
  // 问题记录 = 本地归纳本:直接展示,不走后端
  if (cmd === '问题记录') {
    showNotebook()
    return
  }
  // 搜索范围 = 本地设置(平台勾选):仅科研区有该链路,学习区忽略
  if (cmd === '搜索范围') {
    if (!isResearch.value) return
    anchorTo('.cmd[data-cmd="搜索范围"]')
    togglePanel('scope')
    return
  }
  // 研究档案 = 科研区的本地项目档案:打开面板,不发请求
  if (cmd === '研究档案') {
    anchorTo('.cmd[data-cmd="研究档案"]')
    togglePanel('archive')
    return
  }
  // 公式查询手册 = 板块词条面板:选板块后发该板块公式的提问
  if (cmd === '公式查询手册') {
    anchorTo('.cmd[data-cmd="公式查询手册"]')
    togglePanel('formula')
    return
  }
  // 待办清单 = 本地任务面板:草稿/日程,不发请求
  if (cmd === '待办清单') {
    anchorTo('.cmd[data-cmd="待办清单"]')
    togglePanel('todo')
    return
  }
  // 输入为空用指令默认问题;不清空输入,由 send 在成功发出后统一清空
  const text = input.value.trim() || cmdDefault(cmd) || cmd
  send(text, cmd)
}

/** 新建对话:当前会话与其进行中的输出原样保留(后台继续生成),切换至新会话 */
async function newConversation() {
  if (!(await askPendingPapers())) return
  createSession()
  greet()
}

/** 归纳面板删除记录:问答对移入回收站(30 天内可恢复),会话删空则整体移除 */
function deleteHistory(id: number) {
  const session = sessions.value.find((s) => s.messages.some((m) => m.id === id))
  if (!session) return
  if (!window.confirm(t('learn.deleteConfirm'))) return

  const idx = session.messages.findIndex((m) => m.id === id)
  const nextUser = session.messages.findIndex((m, i) => i > idx && m.role === 'user')
  const end = nextUser === -1 ? session.messages.length : nextUser
  const removed = session.messages.slice(idx, end)

  // 若删除范围内的回答在等待或正在生成,精确取消对应定时器与流(含未启动的)
  for (const m of removed) cancelReply(m.id)

  // 入回收站:保留板块与所属会话信息,便于恢复后重新分配
  addToTrash({
    id,
    question: removed.find((m) => m.role === 'user')?.content ?? '',
    answer: removed
      .filter((m) => m.role === 'assistant' && m.content)
      .map((m) => m.content)
      .join('\n\n'),
    cat: session.cat,
    sessionId: session.id,
    deletedAt: Date.now(),
    // 回收站恢复按记录写回原工作区,不会串到另一区
    workspace: props.workspace,
  })

  session.messages.splice(idx, end - idx)

  // 会话已无用户消息则整体移除;若删的是当前会话,开启新会话
  if (!session.messages.some((m) => m.role === 'user')) {
    sessions.value = sessions.value.filter((s) => s.id !== session.id)
    if (activeId.value === session.id) {
      createSession()
      greet()
    }
  }
  persistSessions()
  showToast(t('learn.toastTrashed'))
}

/** 归纳面板点击问题:跳回该问答所在的会话上下文并定位 */
function jumpTo(id: number) {
  const session = sessions.value.find((s) => s.messages.some((m) => m.id === id))
  if (!session) return
  activeId.value = session.id
  persistSessions()
  activePanel.value = null
  nextTick(() => {
    listEl.value
      ?.querySelector<HTMLElement>(`[data-msg-id="${id}"]`)
      ?.scrollIntoView({ behavior: 'smooth', block: 'center' })
    flashMsgId.value = id
    if (flashTimer) clearTimeout(flashTimer)
    flashTimer = setTimeout(() => (flashMsgId.value = 0), 1600)
  })
}

/* ---------- 章节导航交互(点击章节 → 知识指引;返回 → 回章节列表) ---------- */

/** 会话内最新的教材文本(粘贴导入或上传的文本文件),供章节导航使用 */
function latestTextbookText(session: ChatSession): string {
  for (const m of [...session.messages].reverse()) {
    if (m.role === 'user' && m.attachment?.text) return m.attachment.text
  }
  return ''
}

/** 对话区点击:承接 MathText 渲染的 cmd:// 契约按钮(章节胶囊 / 返回黄框 / 收录是否) */
function onListClick(e: MouseEvent) {
  const el = (e.target as HTMLElement).closest<HTMLElement>('[data-mg-cmd]')
  if (!el) {
    // 点到对话区空白处:收起导出的语言菜单(菜单自身的点击被 @click.stop 拦住)
    if (exportMenu.value !== null) exportMenu.value = null
    return
  }
  const url = el.dataset.mgCmd || ''
  if (url === 'cmd://back') {
    backToNavList()
    return
  }
  if (url.startsWith('cmd://chapter/')) {
    // 模型输出的百分号编码可能是畸形的:安全解码,失败时保留原文
    const name = chapterNameFromCmd(url)
    if (name !== null) onNavChapter(name)
    return
  }
  if (url === 'cmd://nb/yes' || url === 'cmd://nb/no') {
    const msgEl = (e.target as HTMLElement).closest<HTMLElement>('[data-msg-id]')
    onNotebookChoice(url.endsWith('/yes'), msgEl ? Number(msgEl.dataset.msgId) : 0)
    return
  }
  if (url.startsWith('cmd://nb/jump/')) {
    jumpToNotebookEntry(Number(url.slice('cmd://nb/jump/'.length)))
  }
}

/* ---------- 问题记录(归纳本):解答完询问是否收录,点「是」收纳成档 ---------- */

/** 收录选择:先摘掉按钮(防重复点击),「是」则把本题问答收纳进归纳本;
    无论是否都接一句形式性询问(一次性提问若干问题 → 统一收纳在一档) */
function onNotebookChoice(yes: boolean, msgId: number) {
  const session = activeSession.value
  if (!session) return
  const idx = session.messages.findIndex((m) => m.id === msgId)
  if (idx < 0) return
  const answer = session.messages[idx]
  answer.content = answer.content.replace(/\s*\[(是|否|Yes|No)\]\(cmd:\/\/nb\/(yes|no)\)/g, '')
  if (yes) {
    const question = [...session.messages.slice(0, idx)].reverse().find((m) => m.role === 'user')
    if (question) {
      notebooks.addEntry(question.content, answer.content, session.id, question.id)
      showToast(t('learn.toastNbAdded'))
    }
  }
  session.messages.push({
    id: nextMsgId(),
    role: 'assistant',
    content: yes ? t('learn.nbAfterYes') : t('learn.nbAfterNo'),
  })
  persistSessions()
  scrollBottom()
}

/** 点击「问题记录」指令:打开归纳本词条面板 —— 不往对话框刷记录,
    词条滚动陈列,选中后跳回该问答所在的原对话上下文 */
function showNotebook() {
  anchorTo('.cmd[data-cmd="问题记录"]')
  togglePanel('notebook')
}

/** 打开问题归纳面板(顶部「问题归纳」按钮):面板对齐按钮、从按钮下方展开 */
function toggleSummaryPanel() {
  anchorTo('.sum-btn')
  togglePanel('summary')
}

/** 面板选中词条:关面板,跳回原问答上下文(会话/消息已不存在的给提示) */
function pickNotebookEntry(id: number) {
  activePanel.value = null
  jumpToNotebookEntry(id)
}

/** 公式手册选中板块:关面板,先发澄清请求——请 MG 询问想查哪个具体知识点,
    而不是一股脑列出该领域全部公式(两步流程:先问点、再作答) */
function pickFormula(key: string) {
  activePanel.value = null
  send(t('learn.formulaClarify', { cat: catName(key) }), '公式查询手册')
}

/** 归纳本条目跳回原问答(温故知新) */
function jumpToNotebookEntry(id: number) {
  const entry = notebooks.state.entries.find((e) => e.id === id)
  if (!entry) return
  const session = sessions.value.find((s) => s.id === entry.sessionId)
  if (!session || !session.messages.some((m) => m.id === entry.msgId)) {
    showToast(t('learn.toastNbGone'))
    return
  }
  jumpTo(entry.msgId)
}

/** 点击章节:已讲解过 → 直接跳转到已生成的指引;未讲解 → 请求该章知识指引 */
function onNavChapter(name: string) {
  const session = activeSession.value
  if (!session) return
  const done = session.messages.find((m) => m.role === 'assistant' && m.navGuideFor === name && m.content)
  if (done) {
    jumpTo(done.id)
    return
  }
  if (session.messages.some((m) => m.streaming)) {
    showToast(t('learn.toastBusy'))
    return
  }
  const reply: ChatMsg = {
    id: nextMsgId(), role: 'assistant', content: '', streaming: true, thinking: true,
    navGuideFor: name,
  }
  session.messages.push(reply)
  const live = session.messages[session.messages.length - 1]
  // 教材文本已由后端按 sessionId 缓存(章节导航生成列表时入库),这里只发章节名
  scheduleStream(session, live, `请给出「${name}」这一章的大概知识指引`, 450, {
    cmd: '章节知识指引',
    sessionId: session.id,
    categoryKey: session.cat?.key,
    history: buildHistory(session),
  })
}

/** 「返回」:跳到本会话的章节列表(不重新生成) */
function backToNavList() {
  const session = activeSession.value
  if (!session) return
  const list = [...session.messages].reverse().find((m) => m.role === 'assistant' && m.nav === 'list')
  if (list) jumpTo(list.id)
}

/* ---------- 附件上传(相册 / 拍照 / 文件) ---------- */

const attachOpen = ref(false)
const imgInputEl = ref<HTMLInputElement | null>(null)
const camInputEl = ref<HTMLInputElement | null>(null)
const fileInputEl = ref<HTMLInputElement | null>(null)

function pickAlbum() {
  attachOpen.value = false
  imgInputEl.value?.click()
}

function pickCamera() {
  attachOpen.value = false
  camInputEl.value?.click()
}

function pickFile() {
  attachOpen.value = false
  fileInputEl.value?.click()
}

async function onImage(e: Event) {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  input.value = ''
  if (file) await importImageFile(file)
}

function onFile(e: Event) {
  const input = e.target as HTMLInputElement
  const file = input.files?.[0]
  input.value = ''
  if (!file) return
  if (isResearch.value && isPaperFile(file)) void stagePaperFile(file)
  else attachFileItem(file)
}

/** 文件入库:PDF(pdfjs 提取文本层)/ 文本类(.txt/.md)读取正文随附件保存,其余仅元信息 */
async function attachFileItem(file: File) {
  if (file.name.toLowerCase().endsWith('.pdf') || file.type === 'application/pdf') {
    try {
      const text = await extractPdfText(file)
      if (!text) {
        // 扫描版 PDF(无文本层):按普通文件接收并提示
        attachMessage({ kind: 'file', name: file.name, size: file.size }, file.name)
        showToast(t('learn.toastPdfNoText'))
        return
      }
      attachMessage({ kind: 'file', name: file.name, size: file.size, text }, file.name)
      return
    } catch {
      /* 解析失败按普通文件处理 */
    }
  }
  if (FILE_TEXT_EXT.test(file.name)) {
    try {
      const raw = await file.text()
      const capped = raw.trim().slice(0, FILE_TEXT_MAX)
      attachMessage({ kind: 'file', name: file.name, size: file.size, text: capped }, file.name)
      return
    } catch {
      /* 读取失败按普通文件处理 */
    }
  }
  attachMessage({ kind: 'file', name: file.name, size: file.size }, file.name)
}

/** PDF 文本提取(pdfjs 懒加载:仅首次传 PDF 时拉取,主包体积不受影响) */

/** 图片统一入库:压缩为缩略 dataURL 后作为图片附件发送(相册/拍照/拖入/粘贴共用) */
async function importImageFile(file: File) {
  try {
    const url = await compressImage(file, 800)
    attachMessage({ kind: 'image', name: file.name, url, size: file.size }, file.name)
  } catch {
    showToast(t('acc.toastAvatarFail'))
  }
}

/** 拖入/选择的论文先进入临时语料,解析成功后再询问是否入库。 */
const PAPER_EXT = /\.(pdf|docx|epub|html?|xml|rtf|tex)$/i

function isPaperFile(file: File): boolean {
  return file.type === 'application/pdf'
    || file.type.includes('wordprocessingml')
    || file.type === 'application/epub+zip'
    || PAPER_EXT.test(file.name)
}

function findMessage(id: number): ChatMsg | null {
  for (const session of sessions.value) {
    const found = session.messages.find((m) => m.id === id)
    if (found) return found
  }
  return null
}

function removeMessage(id: number): void {
  for (const session of sessions.value) {
    const index = session.messages.findIndex((m) => m.id === id)
    if (index >= 0) {
      session.messages.splice(index, 1)
      return
    }
  }
}

/** 拖入即用:临时论文直接成为本次对话的上下文,不要求先入库。 */
async function stagePaperFile(file: File): Promise<void> {
  if (!activeSession.value) return
  showToast(t('learn.paperParsing'))
  try {
    const res = await uploadTempPaper(file)
    if (res.duplicate && res.status && res.status !== 'temp') {
      showToast(t('learn.paperAlready'))
      return
    }
    const meta = await getResearchDocMeta(res.docId).catch(() => null)
    const title = meta?.title || file.name
    const pages = res.pages || meta?.pages || 0
    currentPaper.value = null
    stagedPaper.value = { docId: res.docId, title }

    const existing = stagedPapers.value.find((p) => p.docId === res.docId)
    if (existing) {
      persistSessions()
      scrollBottom(false)
      return
    }
    const session = activeSession.value
    const message: ChatMsg = {
      id: nextMsgId(),
      role: 'assistant',
      content: t('learn.paperReady'),
      paperImport: { docId: res.docId, title, pages, status: 'pending' },
    }
    session.messages.push(message)
    stagedPapers.value.push({
      docId: res.docId, title, pages, msgId: message.id,
    })
    if (!flushSessions(true)) showToast(t('learn.toastStorage'))
    scrollBottom(false)
  } catch (err) {
    const message = err instanceof Error && err.message ? err.message : 'unknown'
    showToast(t('learn.paperParseFail', { msg: message }))
  }
}

function pendingStagedPapers(): typeof stagedPapers.value {
  return stagedPapers.value.filter((paper) => {
    const msg = findMessage(paper.msgId)
    return msg?.paperImport?.status !== 'imported'
  })
}

function askPendingPapers(): Promise<boolean> {
  if (!pendingStagedPapers().length) return Promise.resolve(true)
  if (importPromptOpen.value) return Promise.resolve(false)
  importPromptOpen.value = true
  return new Promise((resolve) => {
    importPromptResolve = resolve
  })
}

async function confirmPaperChoices(
  choices: Record<string, 'import' | 'temp' | 'ignore'>,
): Promise<void> {
  if (importPromptBusy.value) return
  importPromptBusy.value = true
  const selected = { ...choices }
  const retry: typeof stagedPapers.value = []
  let completed = false
  let importedAny = false
  try {
    for (const paper of [...stagedPapers.value]) {
      const choice = selected[paper.docId] || 'import'
      const msg = findMessage(paper.msgId)
      // 模型已经完成入库的论文不再重复处理,保留其上下文。
      if (msg?.paperImport?.status === 'imported') continue
      if (choice === 'import') {
        try {
          await importTempPaper(paper.docId, undefined, true)
          if (msg?.paperImport) msg.paperImport.status = 'imported'
          importedAny = true
          showToast(t('learn.paperImported'))
        } catch {
          retry.push(paper)
          showToast(t('learn.paperImportFail'))
        }
      } else if (choice === 'temp') {
        if (msg?.paperImport) msg.paperImport.status = 'temp'
        showToast(t('learn.paperKept'))
      } else {
        try {
          await deletePaperHistory(paper.docId)
        } catch {
          /* 已入库或已删除:忽略删除失败 */
        }
        removeMessage(paper.msgId)
        showToast(t('learn.paperIgnored'))
      }
    }
    completed = retry.length === 0
    if (importedAny) await archivePanelRef.value?.reload?.()
  } finally {
    const imported = stagedPapers.value.filter((paper) => {
      const msg = findMessage(paper.msgId)
      return msg?.paperImport?.status === 'imported'
    })
    const next = [...imported, ...retry]
    const last = next[next.length - 1]
    stagedPapers.value = next
    stagedPaper.value = last ? { docId: last.docId, title: last.title } : null
    if (!flushSessions(true)) showToast(t('learn.toastStorage'))
    importPromptBusy.value = false
    importPromptOpen.value = false
    importPromptResolve?.(completed)
    importPromptResolve = null
  }
}

function cancelPaperPrompt(): void {
  if (importPromptBusy.value) return
  importPromptOpen.value = false
  importPromptResolve?.(false)
  importPromptResolve = null
}



const dragging = ref(false)
let dragHideTimer: ReturnType<typeof setTimeout> | null = null

function onDragOver(e: DragEvent) {
  if (isTouchDevice || !e.dataTransfer?.types.includes('Files')) return
  e.preventDefault()
  dragging.value = true
  if (dragHideTimer) {
    clearTimeout(dragHideTimer)
    dragHideTimer = null
  }
}

/** dragleave 在子元素间穿梭时会频繁触发:延迟收尾,避免遮罩闪烁 */
function onDragLeave() {
  if (dragHideTimer) clearTimeout(dragHideTimer)
  dragHideTimer = setTimeout(() => (dragging.value = false), 120)
}

async function onDropFiles(e: DragEvent) {
  if (isTouchDevice) return
  if (dragHideTimer) clearTimeout(dragHideTimer)
  dragging.value = false
  const files = Array.from(e.dataTransfer?.files ?? [])
  if (!files.length) return
  e.preventDefault()
  if (files.length > MAX_DROP_FILES) {
    showToast(t('learn.toastDropTooMany'))
    return
  }
  for (const f of files) {
    if (f.type.startsWith('image/')) await importImageFile(f)
    else if (isResearch.value && isPaperFile(f)) await stagePaperFile(f)
    else await attachFileItem(f)
  }
}

/* ---------- 粘贴导入(移动端为主:剪贴板图片/文本 → 附件) ---------- */

/** 输入框粘贴到剪贴板文件(截图/复制图片)时:不进输入框,直接作为附件导入 */
function onPaste(e: ClipboardEvent) {
  const items = e.clipboardData?.items
  if (!items) return
  for (const item of items) {
    if (item.kind !== 'file') continue
    const f = item.getAsFile()
    if (!f) continue
    e.preventDefault()
    if (f.type.startsWith('image/')) importImageFile(f)
    else if (isResearch.value && isPaperFile(f)) void stagePaperFile(f)
    else attachFileItem(f)
    return
  }
}

/** 移动端「粘贴导入」按钮:优先读剪贴板图片,退而读文本
    (作为 .txt 附件导入,正文随提示词交给模型阅读理解) */
async function pasteImport() {
  attachOpen.value = false
  // 剪贴板图片(截图/复制的图片)
  try {
    if (navigator.clipboard?.read) {
      const items = await navigator.clipboard.read()
      for (const item of items) {
        const imgType = item.types.find((ty) => ty.startsWith('image/'))
        if (!imgType) continue
        const blob = await item.getType(imgType)
        const ext = imgType.split('/')[1] || 'png'
        await importImageFile(new File([blob], `粘贴图片.${ext}`, { type: imgType }))
        return
      }
    }
  } catch {
    /* 无图片或未授权,继续尝试文本 */
  }
  // 剪贴板文本(复制的文档/题目/论文片段)
  try {
    const text = (await navigator.clipboard.readText()).trim()
    if (!text) {
      showToast(t('learn.toastPasteEmpty'))
      return
    }
    const capped = text.slice(0, PASTE_TEXT_MAX)
    attachMessage(
      { kind: 'file', name: '粘贴文本.txt', size: new Blob([capped]).size, text: capped },
      '粘贴文本.txt',
    )
  } catch {
    showToast(t('learn.toastPasteEmpty'))
  }
}

/** 附件消息:留在当前会话(未分类会话归入未归类),MG 给出附件接收回复 */
function attachMessage(attachment: ChatAttachment, content: string) {
  let session = activeSession.value
  if (!session) session = createSession(FALLBACK_CATEGORY)
  if (!session.cat) session.cat = FALLBACK_CATEGORY
  if (session.messages.some((m) => m.streaming)) {
    if (!session.messages[0]?.streaming) return
    cancelReply(session.messages[0].id)
    session.messages.shift()
  }

  const userMsg: ChatMsg = { id: nextMsgId(), role: 'user', content, attachment }
  session.messages.push(userMsg)
  pinnedToBottom = true
  scrollBottom()
  // 图片以 dataURL 随会话持久化:存储超限时明确提示,避免静默丢失记录。
  // 附件可能很大,必须立即写并拿到真实配额结果,不能等 debounce。
  if (!flushSessions(true)) showToast(t('learn.toastStorage'))

  const reply: ChatMsg = { id: nextMsgId(), role: 'assistant', content: '', streaming: true, thinking: true }
  session.messages.push(reply)
  // 同上:流式期间通过响应式代理更新,界面才能实时刷新
  const live = session.messages[session.messages.length - 1]
  // 契约 [attach:image|file]文件名;粘贴导入的文本带正文(空行分隔),后端交 LLM 阅读理解
  const attachPrompt = `[attach:${attachment.kind}]${attachment.name}${attachment.text ? `\n\n${attachment.text}` : ''}`
  scheduleStream(session, live, attachPrompt, 450, {
    sessionId: session.id,
    categoryKey: session.cat?.key,
    history: buildHistory(session),
  })
}

function fmtSize(bytes?: number): string {
  if (bytes === undefined) return ''
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

/* ---------- 语音输入(浏览器本地识别,Chrome / Edge 可用) ---------- */

/* Web Speech API:results 里的每一项(SpeechRecognitionResult)只有 isFinal,
   识别文本在首个候选上(r[0].transcript)——项本身没有 transcript 属性,
   直接读会得到 undefined 拼进输入框 */
interface SRResult {
  isFinal: boolean
  length: number
  [i: number]: { transcript: string } | undefined
}

interface ISpeechRecognition {
  lang: string
  interimResults: boolean
  /** 持续听写:一句话说完不自动停止,由用户点麦克风结束(长段口述更稳) */
  continuous: boolean
  onresult: ((e: { results: ArrayLike<SRResult> }) => void) | null
  onend: (() => void) | null
  onerror: ((e: { error: string }) => void) | null
  start(): void
  stop(): void
}

type SRConstructor = new () => ISpeechRecognition

function getSR(): SRConstructor | null {
  const w = window as unknown as { SpeechRecognition?: SRConstructor; webkitSpeechRecognition?: SRConstructor }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

const listening = ref(false)
let sr: ISpeechRecognition | null = null
let srBaseText = ''
let srStopToConvert = false // 用户主动点停 → 结束后自动转写数学符号

/* 转写提速编排:说话中后台预热(停顿 800ms 起转,结果攒着不打扰输入框)+
   点停 0ms 本地速转先出符号 + LLM 精修流式覆盖;seq 保证新旧转换互不干扰 */
let convSeq = 0
let convCancel: (() => void) | null = null
let convAcc = '' // 当前流累计结果
let convRaw = '' // 当前流对应的原文
let convLive = false // 是否把流式结果显示到输入框
let convWarmDone = false
let convDebounce: ReturnType<typeof setTimeout> | null = null

function cancelConvert() {
  convSeq++
  convCancel?.()
  convCancel = null
  convLive = false
}

function startConvert(raw: string, live: boolean) {
  if (!raw.trim()) return
  cancelConvert()
  convRaw = raw
  convLive = live
  convAcc = ''
  const seq = convSeq
  // 本次转换开始前的输入框内容(live 模式下通常是本地速转结果):
  // 流式覆盖后若模型半途失败,要能撤回到它,而不是把半截转写留在输入框里
  const fallbackText = input.value
  // 先本地归一大小写(ASR 大小写是噪声,不刻意念"大"一律小写),
  // 再交 LLM 按数学惯例自动判别(矩阵 A/随机变量 X 等该大写则大写)
  convCancel = speechToMath(normalizeSpeechCase(raw), {
    onDelta: (full) => {
      if (seq !== convSeq) return
      convAcc = full
      if (convLive) {
        // 输入框是纯文本:把模型可能输出的 ^/_、LaTeX 记号美化为 Unicode 直读形式
        const pretty = beautifyMath(full)
        if (pretty !== input.value) {
          input.value = pretty
          autoGrow()
        }
      }
    },
    onDone: (full) => {
      if (seq !== convSeq) return
      saveConvert(raw, beautifyMath(full), 'llm') // 精修结果(美化后)入缓存:同句再念零请求
    },
    onFail: () => {
      if (seq !== convSeq) return
      // 撤回本次流式覆盖;用户中途手改过输入框则不动,避免吞掉编辑
      if (convLive && input.value === beautifyMath(convAcc)) {
        input.value = fallbackText
        autoGrow()
      }
      if (!listening.value) showToast(t('learn.toastConvertFail'))
    },
  }).cancel
}

function toggleMic() {
  if (listening.value) {
    srStopToConvert = true
    sr?.stop()
    return
  }
  if (!settingsState.voiceAccess) {
    showToast(t('learn.toastVoiceDenied'))
    return
  }
  const Ctor = getSR()
  if (!Ctor) {
    showToast(t('learn.toastNoSR'))
    return
  }
  sr = new Ctor()
  sr.lang = settingsState.language === 'en' ? 'en-US' : 'zh-CN'
  sr.interimResults = true
  sr.continuous = true
  srBaseText = input.value
  convWarmDone = false
  cancelConvert() // 清理上一次语音遗留的转写流
  sr.onresult = (e) => {
    let final = ''
    let interim = ''
    for (let i = 0; i < e.results.length; i++) {
      const r = e.results[i]
      // 识别文本在首个候选 r[0].transcript 上
      const text = r[0]?.transcript ?? ''
      if (!text) continue
      if (r.isFinal) final += text
      else interim += text
    }
    input.value = srBaseText + final + interim
    autoGrow()
    // 后台预热:停顿 800ms 后把当前文本拿去转写(结果先攒着,点停即展示)
    if (convDebounce) clearTimeout(convDebounce)
    convDebounce = setTimeout(() => {
      convDebounce = null
      if (listening.value && !convWarmDone) {
        convWarmDone = true
        startConvert(input.value, false)
      }
    }, 800)
  }
  sr.onend = () => {
    listening.value = false
    if (convDebounce) {
      clearTimeout(convDebounce)
      convDebounce = null
    }
    // 用户主动点停且有新识别内容 → 转写四档:
    // ① 缓存里有精修结果 → 直接上屏,零网络;
    // ② 说话期间预热已完成 → 直接上屏 LLM 结果;
    // ③ 否则本地编译器 0ms 出符号上屏;
    // ④ LLM 后台精修无感覆盖(结果回写缓存)。
    if (srStopToConvert) {
      srStopToConvert = false
      const raw = input.value
      if (raw.trim() && raw !== srBaseText) {
        const cached = cachedConvert(raw)
        if (cached && cached.source === 'llm') {
          input.value = cached.text
          autoGrow()
        } else if (convRaw === raw && convAcc) {
          convLive = true
          // 与①③④同一口径:预热流是 LLM 原始输出(可能含 ^_{}、LaTeX 记号),
          // 漏掉美化会让同一句话因走哪条路径而长得不一样
          input.value = beautifyMath(convAcc)
          autoGrow()
        } else {
          const local = cached?.text ?? speechMathConvert(raw)
          if (!cached) saveConvert(raw, local, 'local')
          input.value = local
          autoGrow()
          startConvert(raw, true)
        }
      }
    }
  }
  sr.onerror = (e) => {
    listening.value = false
    if (e.error === 'aborted') return
    // 麦克风权限被拒(not-allowed / service-not-allowed)单独提示
    if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
      showToast(t('learn.toastMicDenied'), 3600)
      return
    }
    // 安卓设备的识别走 Google 语音服务,国内网络不通时上报 network
    showToast(e.error === 'network' ? t('learn.toastVoiceNetwork') : t('learn.toastNoVoice'))
  }
  listening.value = true
  try {
    sr.start()
  } catch {
    listening.value = false
  }
}

/** 模型语音回复开关(功能待开发,开启后仍以文本回复) */
function setModelVoice(on: boolean) {
  updateSettings({ modelVoice: on })
  if (on) showToast(t('learn.toastVoiceDev'))
}

/* ---------- 初始化 ---------- */

function greet() {
  const session = activeSession.value ?? createSession()
  const reply: ChatMsg = { id: nextMsgId(), role: 'assistant', content: '', streaming: true, thinking: true }
  session.messages.push(reply)
  // 欢迎语是罐头文案:零延迟立即请求,配合首帧立即上屏 → 进入面板即刻出字。
  // live 取数组里的响应式代理:流式回调改它的字段,界面才会实时刷新
  const live = session.messages[session.messages.length - 1]
  scheduleStream(session, live, '', 0)
}

function restoreStagedPapers(): void {
  const seen = new Set<string>()
  for (const session of sessions.value) {
    for (const msg of session.messages) {
      const info = msg.paperImport
      if (!info || info.status !== 'pending' || seen.has(info.docId)) continue
      seen.add(info.docId)
      stagedPapers.value.push({
        docId: info.docId,
        title: info.title,
        pages: info.pages,
        msgId: msg.id,
      })
      stagedPaper.value = { docId: info.docId, title: info.title }
    }
  }
}

onMounted(() => {
  // 每次进入页面都开启全新对话;旧会话自动归档到相应板块
  // (会话档案由 stores/sessions 在应用启动时恢复)
  sessions.value = sessions.value.filter((s) => s.cat
    || s.messages.some((m) => m.role === 'user' || m.paperImport))
  restoreStagedPapers()
  createSession()
  greet()
  // 文献检索页「基于这些结果提问」:证据已拼好,进对话后直接发送
  if (isResearch.value) {
    const seed = sessionStorage.getItem('mg-research-seed')
    if (seed) {
      sessionStorage.removeItem('mg-research-seed')
      nextTick(() => send(seed))
    }
    void loadTableContext()
  }
  window.addEventListener('resize', onWorkspaceResize)
  window.addEventListener('beforeunload', warnPendingPapers)
})

onBeforeRouteLeave(async () => {
  if (!pendingStagedPapers().length) return true
  return askPendingPapers()
})

function warnPendingPapers(event: BeforeUnloadEvent): void {
  if (!pendingStagedPapers().length) return
  flushSessions(true)
  event.preventDefault()
  event.returnValue = ''
}

onBeforeUnmount(() => {
  window.removeEventListener('resize', onWorkspaceResize)
  window.removeEventListener('beforeunload', warnPendingPapers)
  stopAllStreams()
  sr?.stop()
  cancelConvert()
  if (convDebounce) clearTimeout(convDebounce)
  if (flashTimer) clearTimeout(flashTimer)
})
</script>

<template>
  <div class="learn" @dragover="onDragOver" @dragleave="onDragLeave" @drop="onDropFiles">
    <header class="chat-header">
      <button class="back" @click="router.push('/home')">{{ t('common.back') }}</button>
      <div class="title-box">
        <span class="title">{{ t(isResearch ? 'research.title' : 'learn.title') }}</span>
        <span class="tech-label sub">{{ isResearch ? 'MODULE 02 · RESEARCH' : 'MODULE 01 · LEARN' }}</span>
      </div>
      <div class="right">
        <button
          v-if="isResearch"
          class="new-btn"
          :class="{ 'new-btn--active': searchOpen }"
          @click="openResearchSearch"
        >
          {{ t('search.button') }}
        </button>
        <button v-if="isResearch" class="new-btn" @click="router.push('/research/tables')">
          {{ t('tables.entry') }}
        </button>
        <button class="new-btn" @click="newConversation">{{ t('learn.newChat') }}</button>
        <!-- 板块上下文徽章(未归类会话不显示标题) -->
        <span v-if="activeSession?.cat && activeSession.cat.key !== 'other'" class="session-chip">
          <span class="dot" :style="{ background: activeSession.cat.color }"></span>
          {{ catName(activeSession.cat.key) }}{{ t('learn.context') }}
        </span>
        <span v-else-if="!activeSession?.cat" class="session-chip session-chip--dim">{{ t('learn.newSession') }}</span>
        <button v-if="!isResearch" class="sum-btn" @click="toggleSummaryPanel()">
          {{ t('learn.archive') }}<span v-if="questionCount" class="sum-badge">{{ questionCount }}</span>
        </button>
        <span class="badge tech-label">{{ t(isResearch ? 'common.mgResearch' : 'common.mgLearn') }}</span>
        <button class="dots-btn" :title="t('common.settings')" @click="router.push('/settings')">···</button>
      </div>
    </header>

    <!-- 问题归纳面板:浮层形态,对齐「问题归纳」按钮,从按钮下方展开 -->
    <Transition name="cat-drop">
      <CategoryPanel
        v-if="!isResearch && activePanel === 'summary'"
        :items="summary"
        :total="questionCount"
        :left="panelAnchor?.left"
        :top="panelAnchor ? panelAnchor.top + 6 : undefined"
        :width="panelAnchor?.width"
        @close="activePanel = null"
        @jump="jumpTo"
        @delete="deleteHistory"
      />
    </Transition>


    <!-- 念法速查贴士(语音输入中点击麦克风旁的📓打开) -->
    <SpeechTips v-if="tipsOpen" @close="tipsOpen = false" />

    <!-- 对话区(当前会话) -->
    <div ref="workspaceBodyRef" class="workspace-body" :class="{ 'with-search': searchOpen }">
      <div class="chat-pane">
        <div ref="listEl" class="chat-list" @scroll="onListScroll" @click="onListClick">
      <template v-if="activeSession">
        <div
          v-for="m in activeSession.messages"
          :key="m.id"
          class="msg"
          :class="[m.role, { flash: m.id === flashMsgId }]"
          :data-msg-id="m.id"
        >
          <div class="bubble">
            <div v-if="m.attachment" class="attach">
              <img
                v-if="m.attachment.kind === 'image' && m.attachment.url"
                class="attach-img"
                :src="m.attachment.url"
                :alt="m.attachment.name"
              />
              <div v-else>
                <div class="attach-file">
                  <span class="af-icon">📄</span>
                  <span class="af-meta">
                    <span class="af-name">{{ m.attachment.name }}</span>
                    <span class="af-size">{{ fmtSize(m.attachment.size) }}</span>
                  </span>
                </div>
                <!-- 粘贴导入的文本:气泡内展示正文预览 -->
                <div v-if="m.attachment.text" class="af-preview">
                  {{ m.attachment.text.slice(0, 200) }}{{ m.attachment.text.length > 200 ? '…' : '' }}
                </div>
              </div>
            </div>
            <div v-if="m.paperImport" class="paper-imp">
              <div class="paper-imp-head">
                <span class="paper-imp-icon">📄</span>
                <span class="paper-imp-name" :title="m.paperImport.title">{{ m.paperImport.title }}</span>
                <span class="paper-imp-pages">{{ t('learn.paperPages', { n: m.paperImport.pages }) }}</span>
              </div>
              <p class="paper-imp-q">{{ m.content }}</p>
              <p v-if="m.paperImport.status !== 'pending'" class="paper-imp-state">
                {{ m.paperImport.status === 'imported' ? t('learn.paperImported') : t('learn.paperKept') }}
              </p>
            </div>
            <!-- 走 cmdName 而非裸键:契约键是中文,英文界面下会露出中文 -->
            <span v-if="m.role === 'user' && m.cmd" class="cmd-tag">{{ cmdName(m.cmd) }}</span>
            <span v-if="m.role === 'user' && activeSession.cat" class="cat-chip">
              <span class="cat-dot" :style="{ background: activeSession.cat.color }"></span>{{ catName(activeSession.cat.key) }}
            </span>
            <template v-if="m.role === 'assistant'">
              <span v-if="m.thinking" class="thinking">{{ t('learn.thinking') }}<span class="dots">···</span></span>
              <!-- 跨板块知识点:先选方向,再发请求 -->
              <div v-if="m.clarify" class="clarify">
                <p class="clarify-title">{{ t('clarify.title') }}</p>
                <p class="clarify-scope">{{ t('clarify.scope', { scope: clarifyScope(m.clarify.topicId) }) }}</p>
                <div class="clarify-options">
                  <button
                    v-for="(option, oi) in clarifyOptions(m.clarify.topicId)"
                    :key="`${option.key}-${oi}`"
                    class="clarify-opt"
                    type="button"
                    @click.stop="pickClarify(m, oi)"
                  >
                    <span class="co-label">{{ clarifyLabel(option) }}</span>
                    <span class="co-hint">{{ clarifyHint(option) }}</span>
                  </button>
                </div>
              </div>
              <div v-if="m.content && !m.paperImport" class="mg-blocks">
                <template v-for="block in messageBlocks(m)" :key="block.key">
                  <MathText v-if="block.kind === 'text'" :text="block.text || ''" />
                  <DiagramBoundary
                    v-else-if="block.diagram"
                    :title="block.diagram.spec.title"
                    :notes="block.diagram.spec.annotations.map((note) => note.text)"
                  >
                    <DiagramBlockView :spec="block.diagram.spec" />
                  </DiagramBoundary>
                </template>
              </div>
              <button
                v-if="m.content && !m.streaming && !m.paperImport
                  && previousQuestion(m) && !hasDiagram(m)"
                class="diagram-btn"
                type="button"
                :disabled="diagramBusy === m.id"
                @click.stop="requestDiagram(m)"
              >{{ diagramBusy === m.id ? t('diagram.generating') : t('diagram.generate') }}</button>
              <span v-if="m.streaming && !m.thinking" class="cursor">▍</span>
              <!-- 半截回答的标记:与完整回答同形,不点明用户看不出缺了一段 -->
              <span v-if="m.interrupted" class="cut-note">{{ t('learn.interrupted') }}</span>
              <!-- 研究综述的导出入口(仅后端标记过的研究消息显示) -->
              <template v-if="m.research && !m.streaming">
                <button
                  class="export-btn"
                  type="button"
                  :disabled="exportingMsg === m.id"
                  @click.stop="exportMenu = exportMenu === m.id ? null : m.id"
                >
                  {{ exportingMsg === m.id ? t('learn.exporting') : t('learn.exportPdf') }}
                </button>
                <div v-if="exportMenu === m.id" class="export-menu" @click.stop>
                  <span class="export-menu-title">{{ t('learn.exportLangTitle') }}</span>
                  <button type="button" @click="doExport(m, 'zh')">{{ t('learn.exportLangZh') }}</button>
                  <button type="button" @click="doExport(m, 'en')">{{ t('learn.exportLangEn') }}</button>
                </div>
              </template>
              <!-- 用户停止生成后的续写入口:右下角小按钮 -->
              <div v-if="m.stopped && m.content && !m.streaming" class="resume-row">
                <button class="resume-btn" type="button" :title="t('learn.resumeHint')" @click.stop="resumeReply(m)">
                  {{ t('learn.resume') }}
                </button>
              </div>
            </template>
            <template v-else>{{ m.content }}</template>
          </div>
        </div>
      </template>
    </div>

    <!-- 拖拽导入遮罩(电脑端):pointer-events 穿透,事件仍落在 .learn 上 -->
    <div v-if="dragging" class="drop-mask">
      <div class="drop-box">📂 {{ t('learn.dropHint') }}</div>
    </div>

    <!-- 输入区:输入行 + 指令栏 -->
    <footer class="input-bar">
      <div v-if="isResearch && stagedPaper" class="context-chip">
        <span class="context-label">{{ t('chat.paperContext') }}</span>
        <span class="context-name" :title="stagedPaper.title">{{ stagedPaper.title }}</span>
        <button
          class="context-remove"
          :title="t('chat.removePaper')"
          @click="stagedPaper = null"
        >✕</button>
      </div>
      <div v-if="isResearch && tableContext" class="context-chip">
        <span class="context-label">{{ t('chat.tableContext') }}</span>
        <span class="context-name" :title="tableContext.title">{{ tableContext.title }}</span>
        <button
          class="context-remove"
          :title="t('chat.removeTable')"
          @click="tableContext = null"
        >✕</button>
      </div>
      <div class="input-row">
        <!-- 附件:相册照片 / 拍照 / 文件 -->
        <div class="attach-wrap">
          <button class="mic" :class="{ 'is-on': attachOpen }" :title="t('learn.attach')" @click="attachOpen = !attachOpen">
            ＋
          </button>
          <div v-if="attachOpen" class="pop-overlay" @click="attachOpen = false"></div>
          <div v-if="attachOpen" class="attach-pop">
            <button class="attach-btn" @click="pickAlbum()">🖼️ {{ t('learn.attachAlbum') }}</button>
            <button class="attach-btn" @click="pickCamera()">📷 {{ t('learn.attachCamera') }}</button>
            <button class="attach-btn" @click="pickFile()">📄 {{ t('learn.attachFile') }}</button>
            <!-- 移动端专属:从剪贴板粘贴导入(复制图片/文档 → 一键导入) -->
            <button v-if="isTouchDevice" class="attach-btn" @click="pasteImport()">📋 {{ t('learn.attachPaste') }}</button>
          </div>
        </div>
        <input ref="imgInputEl" type="file" accept="image/*" hidden @change="onImage" />
        <input ref="camInputEl" type="file" accept="image/*" capture="environment" hidden @change="onImage" />
        <input ref="fileInputEl" type="file" hidden @change="onFile" />
        <!-- 语音输入:点一下开始、再点一下完成;进行中麦克风旁弹出📓念法本子,
             点开可查念法(不打断输入进程) -->
        <div class="mic-wrap">
          <button
            v-if="listening"
            class="tips-btn"
            :title="t('tips.title')"
            @click="activePanel = null; tipsOpen = !tipsOpen"
          >
            📓
          </button>
          <button
            class="mic"
            :class="{ listening }"
            :title="listening ? t('learn.stopListening') : t('learn.voiceInput')"
            @click="toggleMic"
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v6a3 3 0 0 0 3 3z" />
              <path d="M19 11a7 7 0 0 1-14 0" />
              <path d="M12 18v3" />
            </svg>
          </button>
        </div>
        <textarea
          ref="inputEl"
          v-model="input"
          rows="1"
          class="input"
          :placeholder="listening ? t('learn.listening') : t('learn.placeholder')"
          @input="autoGrow"
          @keydown.enter.exact.prevent="send()"
          @paste="onPaste"
        ></textarea>
        <!-- 生成中变为「停止生成」:可中断长回答,已生成内容保留 -->
        <button class="send" :class="{ 'is-stop': busy }" @click="busy ? stopGenerating() : send()">
          {{ busy ? t('learn.stop') : t('learn.send') }}
        </button>
      </div>
      <!-- 三个底部浮层面板:各包独立 Transition(Transition 要求恰好一个子元素);
           遮罩统一挂在页尾(见下),点任意暗处收起 -->
      <Transition name="nb-rise">
        <NotebookPanel
          v-if="activePanel === 'notebook'"
          :entries="notebooks.state.entries"
          :left="panelAnchor?.left"
          :width="panelAnchor?.width"
          @close="activePanel = null"
          @pick="pickNotebookEntry"
        />
      </Transition>
      <Transition name="nb-rise">
        <FormulaPanel
          v-if="activePanel === 'formula'"
          :left="panelAnchor?.left"
          :width="panelAnchor?.width"
          @close="activePanel = null"
          @pick="pickFormula"
        />
      </Transition>
      <Transition name="nb-rise">
        <ResearchScopePanel
          v-if="isResearch && activePanel === 'scope'"
          :left="panelAnchor?.left"
          :width="panelAnchor?.width"
          @close="activePanel = null"
        />
      </Transition>
      <Transition name="nb-rise">
        <ResearchArchivePanel
          ref="archivePanelRef"
          v-if="isResearch && activePanel === 'archive'"
          :left="panelAnchor?.left"
          :width="panelAnchor?.width"
          @close="closePanel"
          @open-doc="openPaperWorkspace"
        />
      </Transition>
      <Transition name="nb-rise">
        <TodoPanel
          v-if="activePanel === 'todo'"
          :left="panelAnchor?.left"
          :width="panelAnchor?.width"
          @close="activePanel = null"
        />
      </Transition>

      <div class="commands">
        <span class="tech-label cmd-label">{{ t('learn.cmdLabel') }}</span>
        <button
          v-for="c in commands"
          :key="c.key"
          class="cmd"
          :class="{ 'cmd--active': c.key === '搜索范围' && !isAllSelected() }"
          :title="cmdHint(c.key)"
          :data-cmd="c.key"
          @click="runCommand(c.key)"
        >
          <span class="cmd-icon">{{ c.icon }}</span>{{ cmdName(c.key) }}
          <!-- 范围缩小到部分平台时常驻数字,提醒当前不是全平台检索 -->
          <span v-if="c.key === '搜索范围' && !isAllSelected()" class="cmd-badge">{{ selectedSources.length }}</span>
        </button>
        <span class="voice-toggle">
          <span class="voice-label">{{ t('learn.voiceLabel') }}</span>
          <MgSwitch
            size="sm"
            :model-value="settingsState.modelVoice"
            :title="t('learn.voiceHint')"
            @update:model-value="setModelVoice"
          />
          <span class="dev-badge">{{ t('common.tbd') }}</span>
        </span>
      </div>
    </footer>
      </div><!-- /chat-pane -->

      <div
        v-if="searchOpen"
        class="split-divider"
        :class="{ dragging: splitResizing }"
        role="separator"
        aria-orientation="vertical"
        tabindex="0"
        @pointerdown="startSplitDrag"
        @dblclick="resetSplit"
        @keydown.left.prevent="nudgeSplit(-0.02)"
        @keydown.right.prevent="nudgeSplit(0.02)"
      ></div>
      <aside
        v-if="searchOpen"
        class="search-pane"
        :style="{ width: `${splitRatio * 100}%` }"
      >
        <ResearchSearchView
          ref="searchPaneRef"
          embedded
          @ask="onSplitAsk"
          @paper-change="onPaperChange"
        />
      </aside>
    </div><!-- /workspace-body -->

    <!-- 浮层面板统一遮罩:压暗全屏,点任意暗处收起当前面板(收起后按钮才可点) -->
    <Transition name="mask-fade">
      <div v-if="activePanel" class="panel-overlay" @click="closePanel"></div>
    </Transition>

    <PaperImportPrompt
      v-if="importPromptOpen"
      :papers="stagedPapers"
      @confirm="confirmPaperChoices"
      @cancel="cancelPaperPrompt"
    />

    <!-- 论文工作台:研究档案「继续」进入,左对话右阅读器,第三栏结构/导图 -->
    <PaperWorkspace
      v-if="paperDocId"
      :doc-id="paperDocId"
      @close="paperDocId = null"
    />

    <!-- 生成文档:当前会话问答 / 问题归纳 / 独立要求 -->
    <DocModal
      v-if="docOpen"
      :messages="activeSession?.messages ?? []"
      :entries="notebooks.state.entries"
      @close="docOpen = false"
    />

    <!-- 待办提醒:仅在学习辅助页挂载,满足“开场+登录+进入本页”后才提醒 -->
    <TodoReminder />
  </div>
</template>

<style scoped>
.learn {
  height: 100vh;
  display: flex;
  flex-direction: column;
  position: relative;
}

.workspace-body {
  flex: 1;
  min-height: 0;
  display: flex;
}

.chat-pane {
  flex: 1;
  min-width: 0;
  min-height: 0;
  display: flex;
  flex-direction: column;
}

.split-divider {
  flex: none;
  width: 6px;
  cursor: col-resize;
  background: var(--line);
  position: relative;
  z-index: 3;
  touch-action: none;
}

.split-divider:hover,
.split-divider:focus-visible,
.split-divider.dragging {
  background: color-mix(in srgb, var(--cyan) 55%, transparent);
  outline: none;
}

.search-pane {
  flex: none;
  min-width: 0;
  height: 100%;
  overflow: hidden;
}

.chat-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 12px 22px;
  border-bottom: 1px solid var(--line);
  background: var(--bg-panel);
  backdrop-filter: blur(8px);
}

.back {
  background: transparent;
  border: 1px solid var(--line);
  color: var(--text);
  padding: 7px 16px;
  cursor: pointer;
  border-radius: 4px;
  font-size: 13px;
  transition: all var(--dur-fast) var(--ease-out);
}

.back:hover {
  color: var(--cyan);
  border-color: var(--line-bright);
  box-shadow: var(--glow-cyan);
}

.title-box {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.title {
  color: var(--text-hi);
  font-size: 15px;
  letter-spacing: 0.06em;
}

.sub {
  font-size: 10px;
}

.right {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 12px;
}

.badge {
  color: var(--cyan);
  border: 1px solid var(--line-bright);
  padding: 5px 12px;
  border-radius: 999px;
  font-size: 11px;
}

.session-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--text-hi);
  border: 1px solid var(--line);
  padding: 5px 12px;
  border-radius: 999px;
}

.session-chip .dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
}

.session-chip--dim {
  color: var(--text-dim);
}

.new-btn {
  background: color-mix(in srgb, var(--cyan) 8%, transparent);
  border: 1px solid var(--line-bright);
  color: var(--cyan);
  padding: 5px 14px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  letter-spacing: 0.06em;
  transition: all var(--dur-fast) var(--ease-out);
}

.new-btn:hover {
  background: color-mix(in srgb, var(--cyan) 16%, transparent);
  box-shadow: var(--glow-cyan);
}

.new-btn--active {
  background: color-mix(in srgb, var(--cyan) 18%, transparent);
  box-shadow: var(--glow-cyan);
}

.sum-btn {
  background: transparent;
  border: 1px solid var(--line);
  color: var(--text-dim);
  padding: 5px 12px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: all var(--dur-fast) var(--ease-out);
}

.sum-btn:hover {
  color: var(--cyan);
  border-color: var(--line-bright);
  box-shadow: var(--glow-cyan);
}

.sum-badge {
  display: inline-grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 999px;
  background: rgba(77, 214, 255, 0.15);
  color: var(--cyan);
  font-family: var(--font-tech);
  font-size: 10px;
}

/* ---------- 对话区 ---------- */
.chat-list {
  flex: 1;
  overflow-y: auto;
  padding: 22px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.msg {
  display: flex;
  scroll-margin: 20px 0;
}

.msg.user {
  justify-content: flex-end;
}

.bubble {
  max-width: 78%;
  padding: 12px 16px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.75;
}

.msg.user .bubble {
  background: color-mix(in srgb, var(--cyan) 9%, transparent);
  border: 1px solid color-mix(in srgb, var(--cyan) 32%, transparent);
  color: var(--text-hi);
  border-bottom-right-radius: 4px;
  white-space: pre-wrap;
  word-break: break-word;
}

.msg.assistant .bubble {
  background: var(--bg-card);
  border: 1px solid var(--line);
  border-bottom-left-radius: 4px;
}

/* 跨板块澄清卡:给出范围 + 方向按钮 */
.clarify {
  width: min(500px, 100%);
  display: flex;
  flex-direction: column;
  gap: 7px;
}

.clarify-title {
  margin: 0;
  color: var(--text-hi);
  font-size: 13.5px;
  line-height: 1.55;
}

.clarify-scope {
  margin: 0;
  color: var(--text-dim);
  font-size: 11.5px;
  line-height: 1.65;
}

.clarify-options {
  display: flex;
  flex-direction: column;
  gap: 6px;
  margin-top: 2px;
}

.clarify-opt {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 8px 11px;
  text-align: left;
  color: var(--text);
  background: var(--bg-void);
  border: 1px solid var(--line);
  border-radius: 8px;
  cursor: pointer;
  transition: border-color var(--dur-fast), box-shadow var(--dur-fast);
}

.clarify-opt:hover,
.clarify-opt:focus-visible {
  border-color: var(--line-bright);
  box-shadow: var(--glow-cyan);
  outline: none;
}

.co-label {
  color: var(--cyan);
  font-size: 12.5px;
}

.co-hint {
  color: var(--text-dim);
  font-size: 11px;
  line-height: 1.55;
}

/* 归纳跳转定位后的高亮 */
.msg.flash .bubble {
  animation: msg-flash 1.6s ease-out;
}

@keyframes msg-flash {
  0% {
    border-color: var(--cyan);
    box-shadow: var(--glow-cyan);
  }
  100% {
    border-color: var(--line);
    box-shadow: none;
  }
}

.cmd-tag,
.cat-chip {
  display: inline-block;
  font-family: var(--font-tech);
  font-size: 10px;
  border: 1px solid var(--line-bright);
  padding: 1px 8px;
  border-radius: 999px;
  margin-right: 8px;
  vertical-align: 2px;
}

.cmd-tag {
  color: var(--cyan);
}

.cat-chip {
  color: var(--text-dim);
  border-color: var(--line);
}

.cat-dot {
  display: inline-block;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  margin-right: 5px;
  vertical-align: 1px;
}

.thinking {
  color: var(--text-dim);
  font-size: 13px;
}

.dots {
  animation: mg-blink 1.2s steps(1) infinite;
}

.cursor {
  display: inline-block;
  animation: mg-blink 1s steps(1) infinite;
  color: var(--cyan);
  margin-left: 2px;
}

/* 中断标记:另起一行、弱化处理 —— 它是对这条回答的批注,不是回答本身 */
.cut-note {
  display: block;
  margin-top: 8px;
  padding-top: 7px;
  border-top: 1px dashed var(--line);
  color: var(--text-dim);
  font-size: 11.5px;
  line-height: 1.5;
}

/* 停止生成后的续写入口:气泡右下角 */
.resume-row {
  display: flex;
  justify-content: flex-end;
  margin-top: 8px;
}

.resume-btn {
  padding: 3px 12px;
  border: 1px solid var(--line-bright);
  border-radius: 999px;
  background: color-mix(in srgb, var(--cyan) 8%, transparent);
  color: var(--cyan);
  font-size: 11.5px;
  cursor: pointer;
  transition: all var(--dur-fast) var(--ease-out);
}

.resume-btn:hover {
  background: color-mix(in srgb, var(--cyan) 16%, transparent);
  box-shadow: var(--glow-cyan);
}

/* 研究综述导出:小按钮 + 语言选择菜单 */
.export-btn {
  display: inline-block;
  margin-top: 10px;
  padding: 4px 14px;
  border: 1px solid var(--line-bright);
  border-radius: 999px;
  background: color-mix(in srgb, var(--cyan) 8%, transparent);
  color: var(--cyan);
  font-size: 12px;
  cursor: pointer;
  transition: all var(--dur-fast) var(--ease-out);
}

.export-btn:hover {
  box-shadow: var(--glow-cyan);
}

.export-btn:disabled {
  opacity: 0.55;
  cursor: wait;
}

.diagram-btn {
  display: inline-block;
  margin-top: 8px;
  margin-left: 6px;
  padding: 3px 10px;
  border: 1px solid var(--line);
  border-radius: 999px;
  background: transparent;
  color: var(--text-dim);
  font-size: 10.5px;
  cursor: pointer;
}

.diagram-btn:hover {
  color: var(--cyan);
  border-color: var(--line-bright);
}

.diagram-btn:disabled {
  opacity: 0.55;
  cursor: wait;
}

.export-menu {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
  margin-top: 6px;
  padding: 8px;
  width: fit-content;
  background: var(--bg-panel);
  border: 1px solid var(--line);
  border-radius: 8px;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
}

.export-menu-title {
  font-size: 10.5px;
  color: var(--text-dim);
  padding: 0 6px 4px;
}

.export-menu button {
  width: 100%;
  text-align: left;
  background: transparent;
  border: none;
  color: var(--text);
  font-size: 13px;
  padding: 5px 8px;
  border-radius: 5px;
  cursor: pointer;
}

.export-menu button:hover {
  background: rgba(96, 165, 250, 0.1);
  color: var(--cyan);
}

/* ---------- 输入区 ---------- */
.input-bar {
  position: relative; /* 问题记录面板与附件弹层以此为定位锚点 */
  border-top: 1px solid var(--line);
  background: var(--bg-panel);
  padding: 12px 22px 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.context-chip {
  display: flex;
  align-items: center;
  gap: 8px;
  align-self: flex-start;
  max-width: 100%;
  padding: 4px 10px;
  border: 1px solid var(--line-bright);
  border-radius: 999px;
  background: color-mix(in srgb, var(--cyan) 7%, transparent);
  font-size: 11px;
}

.context-label {
  color: var(--cyan);
  font-family: var(--font-tech);
  font-size: 9.5px;
  letter-spacing: 0.06em;
}

.context-name {
  max-width: 320px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--text-hi);
}

.context-remove {
  background: transparent;
  border: none;
  color: var(--text-dim);
  font-size: 11px;
  cursor: pointer;
  padding: 0 2px;
}

.context-remove:hover {
  color: var(--cyan);
}

/* 浮层面板统一全屏遮罩:压暗其余界面,面板浮在其上(两层效果),
   点任意暗处收起面板 —— 收起前其余按钮被遮罩拦截,不可点击 */
.panel-overlay {
  position: fixed;
  inset: 0;
  z-index: 40;
  background: rgba(3, 6, 12, 0.55);
  backdrop-filter: blur(1.5px);
}

.mask-fade-enter-active,
.mask-fade-leave-active {
  transition: opacity 0.2s;
}

.mask-fade-enter-from,
.mask-fade-leave-to {
  opacity: 0;
}

/* 底部面板(问题记录):从下向上展开 / 从上向下收起 */
.nb-rise-enter-active {
  transition: transform 0.22s var(--ease-out), opacity 0.22s;
}

.nb-rise-leave-active {
  transition: transform 0.18s var(--ease-in), opacity 0.18s;
}

.nb-rise-enter-from,
.nb-rise-leave-to {
  transform: translateY(26px);
  opacity: 0;
}

/* 顶部面板(问题归纳):从按钮下方落下展开 / 向上收起 */
.cat-drop-enter-active {
  transition: transform 0.22s var(--ease-out), opacity 0.22s;
}

.cat-drop-leave-active {
  transition: transform 0.18s var(--ease-in), opacity 0.18s;
}

.cat-drop-enter-from,
.cat-drop-leave-to {
  transform: translateY(-12px);
  opacity: 0;
}

.input-row {
  display: flex;
  align-items: flex-end;
  gap: 12px;
}

.input {
  flex: 1;
  resize: none;
  background: var(--bg-card);
  border: 1px solid var(--line);
  border-radius: 10px;
  color: var(--text);
  font-family: var(--font-ui);
  font-size: 14px;
  line-height: 1.6;
  padding: 11px 14px;
  outline: none;
  max-height: 160px;
  transition:
    border-color var(--dur-fast),
    box-shadow var(--dur-fast);
}

.input:focus {
  border-color: var(--line-bright);
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--cyan) 10%, transparent);
}

.input::placeholder {
  color: var(--text-dim);
}

.send {
  background: color-mix(in srgb, var(--cyan) 12%, transparent);
  border: 1px solid var(--line-bright);
  color: var(--cyan);
  padding: 11px 26px;
  border-radius: 10px;
  cursor: pointer;
  font-size: 14px;
  letter-spacing: 0.1em;
  transition: all var(--dur-fast) var(--ease-out);
}

.send:hover:not(:disabled) {
  background: color-mix(in srgb, var(--cyan) 18%, transparent);
  box-shadow: var(--glow-cyan);
}

.send:disabled {
  opacity: 0.45;
  cursor: not-allowed;
}

/* 停止生成态:暖黄色警示,点击中断当前回答 */
.send.is-stop {
  color: #ffd166;
  border-color: rgba(255, 209, 102, 0.5);
  background: rgba(255, 209, 102, 0.1);
}

.send.is-stop:hover {
  background: rgba(255, 209, 102, 0.18);
  box-shadow: 0 0 12px rgba(255, 209, 102, 0.25);
}

/* ---------- 指令栏(位于输入行下方) ---------- */
.commands {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.cmd-label {
  color: var(--text-dim);
  font-size: 10px;
  margin-right: 4px;
}

.cmd {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: transparent;
  border: 1px solid var(--line);
  color: var(--text);
  padding: 5px 13px;
  border-radius: 999px;
  cursor: pointer;
  font-size: 12px;
  letter-spacing: 0.05em;
  transition: all var(--dur-fast) var(--ease-out);
}

.cmd:hover {
  color: var(--cyan);
  border-color: var(--line-bright);
  box-shadow: var(--glow-cyan);
  transform: translateY(-2px);
}

.cmd-icon {
  font-size: 11px;
  color: var(--cyan);
}

/* 搜索范围已缩小到部分平台:常驻高亮 + 数量角标 */
.cmd--active {
  border-color: var(--line-bright);
  color: var(--cyan);
}

.cmd-badge {
  font-family: var(--font-tech);
  font-size: 10px;
  line-height: 1;
  padding: 2px 5px;
  border-radius: 999px;
  background: var(--cyan);
  color: #0b1220;
}

/* ---------- 附件 ---------- */
.attach-wrap {
  position: relative;
  flex-shrink: 0;
}

.mic.is-on {
  color: var(--cyan);
  border-color: var(--line-bright);
  box-shadow: var(--glow-cyan);
}

.pop-overlay {
  position: fixed;
  inset: 0;
  z-index: 30;
}

.attach-pop {
  position: absolute;
  bottom: calc(100% + 10px);
  left: 0;
  z-index: 31;
  min-width: 220px;
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 6px;
  background: var(--bg-panel);
  border: 1px solid var(--line-bright);
  border-radius: 10px;
  backdrop-filter: blur(10px);
  box-shadow: var(--glow-cyan);
}

.attach-btn {
  display: flex;
  align-items: center;
  gap: 10px;
  background: transparent;
  border: none;
  color: var(--text);
  padding: 9px 12px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 13px;
  text-align: left;
  white-space: nowrap;
  transition: all var(--dur-fast);
}

.attach-btn:hover {
  color: var(--cyan);
  background: color-mix(in srgb, var(--cyan) 8%, transparent);
}

.attach {
  margin-bottom: 6px;
}

.paper-imp {
  min-width: 240px;
  margin-bottom: 6px;
  padding: 10px;
  border: 1px solid var(--line-bright);
  border-radius: 8px;
  background: var(--bg-card);
}

.paper-imp-head {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.paper-imp-icon {
  flex: none;
}

.paper-imp-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--text-hi);
  font-size: 12.5px;
}

.paper-imp-pages {
  flex: none;
  color: var(--text-dim);
  font-size: 10.5px;
}

.paper-imp-q {
  margin: 7px 0 8px;
  color: var(--text);
  font-size: 12px;
  line-height: 1.55;
}

.paper-imp-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.paper-imp-btn {
  background: transparent;
  border: 1px solid var(--line);
  color: var(--text-dim);
  border-radius: 5px;
  font-size: 11px;
  padding: 4px 8px;
  cursor: pointer;
}

.paper-imp-btn.primary {
  color: var(--cyan);
  border-color: var(--line-bright);
  background: color-mix(in srgb, var(--cyan) 10%, transparent);
}

.paper-imp-btn:hover {
  color: var(--text-hi);
  border-color: var(--line-bright);
}

.paper-imp-btn:disabled {
  opacity: 0.55;
  cursor: wait;
}

.paper-imp-state {
  margin: 0;
  color: var(--cyan);
  font-size: 11px;
}

.attach-img {
  display: block;
  max-width: 220px;
  max-height: 160px;
  border-radius: 8px;
  border: 1px solid var(--line-bright);
}

.attach-file {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  background: var(--bg-void);
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 8px 12px;
}

.af-icon {
  font-size: 18px;
}

.af-meta {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.af-name {
  font-size: 12.5px;
  color: var(--text-hi);
  max-width: 180px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.af-size {
  font-size: 11px;
  color: var(--text-dim);
  font-family: var(--font-tech);
}

.af-preview {
  margin-top: 6px;
  max-width: 420px;
  font-size: 11.5px;
  line-height: 1.6;
  color: var(--text-dim);
  background: var(--bg-void);
  border: 1px dashed var(--line);
  border-radius: 6px;
  padding: 6px 10px;
  white-space: pre-wrap;
  word-break: break-word;
  display: -webkit-box;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

/* ---------- 拖拽导入遮罩 ---------- */
.drop-mask {
  position: absolute;
  inset: 0;
  z-index: 40;
  display: grid;
  place-items: center;
  background: color-mix(in srgb, var(--bg-void) 72%, transparent);
  backdrop-filter: blur(2px);
  pointer-events: none;
}

.drop-box {
  padding: 34px 56px;
  border: 2px dashed var(--cyan);
  border-radius: 14px;
  color: var(--cyan);
  font-size: 15px;
  letter-spacing: 0.08em;
  background: color-mix(in srgb, var(--cyan) 6%, transparent);
  box-shadow: var(--glow-cyan);
}

/* ---------- 语音 ---------- */
.dots-btn {
  background: transparent;
  border: 1px solid var(--line);
  color: var(--text-dim);
  padding: 5px 12px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 13px;
  letter-spacing: 0.08em;
  transition: all var(--dur-fast) var(--ease-out);
}

.dots-btn:hover {
  color: var(--cyan);
  border-color: var(--line-bright);
  box-shadow: var(--glow-cyan);
}

.mic {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  background: var(--bg-card);
  border: 1px solid var(--line);
  color: var(--text-dim);
  cursor: pointer;
  display: grid;
  place-items: center;
  flex-shrink: 0;
  transition: all var(--dur-fast) var(--ease-out);
}

/* 语音输入中的麦克风与📓念法本子(本子仅语音中弹出) */
.mic-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.tips-btn {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  background: var(--bg-card);
  border: 1px solid var(--line-bright);
  color: var(--cyan);
  cursor: pointer;
  display: grid;
  place-items: center;
  font-size: 17px;
  flex-shrink: 0;
  transition: all var(--dur-fast) var(--ease-out);
  animation: tips-pop 0.25s var(--ease-out);
}

.tips-btn:hover {
  box-shadow: var(--glow-cyan);
  background: color-mix(in srgb, var(--cyan) 10%, transparent);
}

@keyframes tips-pop {
  from {
    transform: scale(0.5);
    opacity: 0;
  }
}

.mic svg {
  width: 20px;
  height: 20px;
  stroke: currentColor;
  fill: none;
  stroke-width: 1.8;
  stroke-linecap: round;
}

.mic:hover {
  color: var(--cyan);
  border-color: var(--line-bright);
  box-shadow: var(--glow-cyan);
}

.mic.listening {
  color: var(--danger);
  border-color: color-mix(in srgb, var(--danger) 60%, transparent);
  box-shadow: 0 0 12px color-mix(in srgb, var(--danger) 35%, transparent);
  animation: mg-pulse 1.1s ease-in-out infinite;
}

.voice-toggle {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 8px;
}

.voice-label {
  color: var(--text-dim);
  font-size: 12px;
}

.dev-badge {
  font-size: 10px;
  font-family: var(--font-tech);
  color: var(--magenta);
  border: 1px solid rgba(255, 77, 210, 0.4);
  border-radius: 999px;
  padding: 0 6px;
}
</style>
