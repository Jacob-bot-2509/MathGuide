# 图解防崩溃机制

日期：2026-11-02
关联：[静态图解方案](STATIC_DIAGRAM_PLAN.md) · [表示形式契约](REPRESENTATION_CONTRACT.md) · [权重网](DIAGRAM_TAXONOMY.md)

目标：图解任一环节失败，只少一张图，不拖垮回答、会话或页面；宁可不出图，也不出错图。

## 1. 后端

| 机制 | 实现 |
| --- | --- |
| 单图异常隔离 | planner 调用、采样、校验、事件序列化各自兜底；异常返回 `None`，正文继续 |
| 规划超时 | 单图 30s；客户端断开时取消全部图解任务 |
| 并发闸 | 全局 `Semaphore(3)`，避免多路 planner 触发上游限流后全失败 |
| 熔断 | 连续 5 次失败后 30s 内不再调用 planner，只留文字；成功后自动恢复 |
| 采样移出事件循环 | `prepare_diagram` 通过 `asyncio.to_thread` 执行，避免 41×41 曲面卡住 SSE |
| 单图上限 | 节点 ≤40、边 ≤80、形状 ≤100、标注 ≤40、点数 ≤2000、坐标 ±1e4 |
| 单消息预算 | 最多 6 张；总点数 ≤8000；事件总字节 ≤200KB |
| 表达式安全 | AST 白名单、节点 ≤80、表达式 ≤200 字符、指数 ≤8，不执行任意代码 |
| 严格 JSON | `json.dumps(allow_nan=False)`；NaN/Infinity 直接丢弃该事件 |
| 类型/结构校验 | 请求类型必须一致；节点型必须有 nodes，几何型必须有 shapes；错类型不画 |
| 手动接口限流 | `SlidingWindowLimiter(12, 60s)` |
| Schema 版本 | 图解带 `schemaVersion`；未来版本直接丢弃；旧数据缺版本按当前版本恢复 |
| 运行指标 | `diagram_metrics` 记录 plan/emit/drop、耗时、点数、失败原因；不含正文或用户身份 |

指标只记录阶段与原因，例如 `plan:ok`、`plan:fail:invalid`、`drop:fail:budget`；快照可通过 `diagram_metrics.snapshot()` 读取，或经认证访问 `GET /api/research/diagrams/metrics`。返回值只有计数、耗时和点数，不含问题、回答或用户身份。

## 2. 前端

| 机制 | 实现 |
| --- | --- |
| 逐图错误边界 | `DiagramBoundary` 捕获单张图渲染异常，只丢这一张；显示图题 + 标注文字作为文字化降级 |
| 异步加载兜底 | Three.js 懒加载有 loading/error 组件，失败不白屏 |
| 视口懒挂载 | 3D 图进入视口才挂载，离开视口卸载，避免 WebGL context 耗尽 |
| WebGL 丢失 | 监听 `webglcontextlost`，阻止默认行为并显示文字提示；卸载继续释放 context |
| 恢复时重新校验 | localStorage 恢复的图解重跑 `parseDiagramSpec`；旧版本/手改/半截数据直接丢弃 |
| 深响应式隔离 | 图解 spec 与图解数组 `markRaw`，避免大量曲面点变成响应式代理卡死主线程 |
| 会话存储 | 保存完整图解，不按数量或点数裁剪已有图解 |
| 配额不足 | 写盘失败时保留上一次完整存档，提示新内容尚未保存；返回 false，可在腾出空间后重试 |
| SSE 解析 | 单帧解析失败返回 null，不影响其他帧 |

## 3. 3D 失败策略

- **语义必需 3D**（用户明确要三维、曲面/梯度/空间关系）：3D 失败**不降级为 2D**，不显示空白画布；只显示图题 + 标注文字，或完全省略。
- **3D 只是装饰**且 2D 能完整表达：才允许降 2D，且必须保持关系等价。
- 禁止固定视角 2D 投影冒充 3D 图。
- 正文始终可独立读懂；图是增强，不是唯一信息载体。

## 4. 测试

- planner 超时、异常、熔断打开/恢复；
- 采样在线程执行；
- NaN 事件被丢弃；
- 总点数预算跳过多余图；
- 恢复时丢弃类型/结构不符的旧图；
- localStorage 配额失败时保留上一次存档，提示未保存并支持重试；
- 单消息 6 张上限、总点数上限；
- 系统级故障演练：planner 崩溃、返回空、熔断打开，正文都必须完整且无图解事件；
- 3D context lost、异步加载失败由边界兜底（手动/浏览器冒烟）。

## 5. 监控入口

- `GET /api/research/diagrams/metrics`：需登录，返回聚合 JSON。
- `GET /api/research/diagrams/metrics?format=prometheus`：Prometheus 文本格式，交给外部抓取。
- 可选 webhook：`MG_DIAGRAM_ALERT_WEBHOOK`；熔断打开时 POST 聚合快照与原因，`MG_DIAGRAM_ALERT_COOLDOWN` 控制同类告警间隔（默认 300s）。
- 告警载荷只有 `service/event/reason/snapshot/ts`，不含问题、回答、用户 ID 或密钥。
- 日志行：`[diagram] <阶段>:<ok|fail>:<原因> ms=<耗时> points=<点数>`。

## 6. 已知缺口

- Prometheus 抓取与 webhook 接收端需运维配置，应用内没有 dashboard；
- 故障演练是测试级，不是生产环境注入；
- 3D 语义必需失败时，文字化降级依赖图题/标注；没有标注时只显示通用提示。
